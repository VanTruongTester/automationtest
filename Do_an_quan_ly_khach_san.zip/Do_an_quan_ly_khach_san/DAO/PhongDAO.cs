﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using DTO;
namespace DAO
{
    public class PhongDAO
    {
        
         private QuanLyKhachSanEntities _qlKhachSan = new QuanLyKhachSanEntities();  
        public List<PhongDTO> LayDSPhong()
        {
            
            return _qlKhachSan.PHONGs.Where(u => u.TrangThai == 1).Select(v => new PhongDTO
            {
               
                MaPhong = v.MaPhong,
                Gia = (int)v.Gia,
                MaLoaiPhong = v.MaLoaiPhong,
                TenLoaiPhong = v.LOAIPHONG.TenLoaiPhong,
                TinhTrang = v.TinhTrang
            }).ToList();
        }
        public PhongDTO LayPhongTheoHoaDonDTO(int MaPhong)
        {
            PHONG phongEF = _qlKhachSan.PHONGs.SingleOrDefault(u => u.MaPhong == MaPhong && u.TrangThai == 1);
            PhongDTO phongDTO = new PhongDTO
            {
                MaPhong=phongEF.MaPhong,
                Gia=phongEF.Gia.Value,
                MaLoaiPhong=phongEF.MaLoaiPhong,
                TinhTrang=phongEF.TinhTrang
            };
            return phongDTO;
        }
        public bool KiemTraTrungLap(int MaPhong)
        {
            PHONG phong = _qlKhachSan.PHONGs.SingleOrDefault(u => u.MaPhong == MaPhong);
            return phong != null;  
        }
        public int MaxMaPhong()
        {
            return _qlKhachSan.PHONGs.Max(u => u.MaPhong);
        }
        public int ThemPhong(PhongDTO phong)
        {
            try
            {
                PHONG phongEF = new PHONG
                {  
                   
                    MaPhong=phong.MaPhong,
                    Gia = phong.Gia,
                    MaLoaiPhong = phong.MaLoaiPhong,
                    TinhTrang="Trống",
                    TrangThai = 1,
                };
                phongEF = _qlKhachSan.PHONGs.Add(phongEF);
                _qlKhachSan.SaveChanges();

                return phongEF.MaPhong;
            }
            catch(Exception e)
            {
                return 0;
            }
        }
        public int CapNhatPhong(PhongDTO phong)
        {
            try
            {
                PHONG phongEF = _qlKhachSan.PHONGs.SingleOrDefault(u =>u.MaPhong == phong.MaPhong);
                phongEF.MaPhong = phong.MaPhong;
                phongEF.Gia = phong.Gia;
                phongEF.MaLoaiPhong = phong.MaLoaiPhong;
                phongEF.TinhTrang = phong.TinhTrang;
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch(Exception e)
            {
                return 0;
            }
        }
        public int XoaPhong(PhongDTO phong)
        {
            try
            {
                PHONG phongEF = _qlKhachSan.PHONGs.SingleOrDefault(u => u.MaPhong == phong.MaPhong);
                phongEF.TrangThai = 0;
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
    }
}

