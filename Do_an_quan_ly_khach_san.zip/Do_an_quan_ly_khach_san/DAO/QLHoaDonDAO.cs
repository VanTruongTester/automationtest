﻿using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class QLHoaDonDAO
    {
        private QuanLyKhachSanEntities _qlKhachSan = new QuanLyKhachSanEntities();
        public List<QLHoaDonDTO> LayDSHoaDonDAO()
        {
            return _qlKhachSan.HOADONs.Where(u => u.TrangThai == 1).Select(v => new QLHoaDonDTO
            {
                MaHD = v.MaHD,
                TenHD = v.TenHD,
                MaNV = (int)v.MaNV,
                HoTenNV = v.HoTenNV,
                MaKH = v.MaKH,
                HoTenKH = v.HoTenKH,
                NgayLapHD = (DateTime)v.NgayLapHD,
                TongTien = (int)v.TongTien,
                MaPhong = (int)v.MaPhong
            }).ToList();
        }
        public List<QLHoaDonDTO> LayDSKhachHangTheoNgay(DateTime ngayLapHD)
        {
            return _qlKhachSan.HOADONs.Where(u => u.TrangThai == 1 && u.NgayLapHD == ngayLapHD).Select(v => new QLHoaDonDTO
            {
                MaHD = v.MaHD,
                TenHD = v.TenHD,
                MaNV = (int)v.MaNV,
                HoTenNV = v.HoTenNV,
                MaKH = v.MaKH,
                HoTenKH = v.HoTenKH,
                NgayLapHD = (DateTime)v.NgayLapHD,
                TongTien = (int)v.TongTien,
                MaPhong = (int)v.MaPhong
            }).ToList();
        }
        public bool KiemTraTrungLap(int MaHD)
        {
            HOADON hoaDon = _qlKhachSan.HOADONs.SingleOrDefault(u => u.MaHD == MaHD);
            return hoaDon != null;
        }
        public int XoaHoaDon(QLHoaDonDTO qlHoaDonDTO)
        {
            try
            {
                HOADON hoaDonEF = _qlKhachSan.HOADONs.SingleOrDefault(u => u.MaHD == qlHoaDonDTO.MaHD);
                hoaDonEF.TrangThai = 0;
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        public int MaxMaHD()
        {
            return Convert.ToInt32(_qlKhachSan.HOADONs.Max(u => u.MaHD));
        }
        public int DatNgay(QLHoaDonDTO qlHoaDonDTO)
        {
            try
            {
                HOADON hoaDonEF = new HOADON
                {
                    MaHD = qlHoaDonDTO.MaHD,
                    TenHD = qlHoaDonDTO.TenHD,
                    MaNV = qlHoaDonDTO.MaNV,
                    HoTenNV = qlHoaDonDTO.HoTenNV,
                    MaKH = qlHoaDonDTO.MaKH,
                    HoTenKH = qlHoaDonDTO.HoTenKH,
                    NgayLapHD = qlHoaDonDTO.NgayLapHD,
                    TongTien = qlHoaDonDTO.TongTien,
                    MaPhong = qlHoaDonDTO.MaPhong,
                    TrangThai = 1,

                };
                hoaDonEF = _qlKhachSan.HOADONs.Add(hoaDonEF);
                _qlKhachSan.SaveChanges();
                return Convert.ToInt32(hoaDonEF.MaHD);
            }
            catch (Exception e)
            {
                return 0;
            }
        }
    }
}
