﻿using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
   public class LoaiPhongDAO
    {
        private QuanLyKhachSanEntities _qlKhachSan = new QuanLyKhachSanEntities();
        public List<LoaiPhongDTO> LayDSLoaiPhong()
        {
            return _qlKhachSan.LOAIPHONGs.Select(u => new LoaiPhongDTO { MaLoaiPhong = u.MaLoaiPhong, TenLoaiPhong = u.TenLoaiPhong }).ToList();
        }
    }
}
