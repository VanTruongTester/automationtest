﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
namespace DAO
{
    public class ChucVuDAO
    {
        private QuanLyKhachSanEntities _qlKhachSan = new QuanLyKhachSanEntities();
        public List<ChucVuDTO> LayDSChuVuDTO()
        {
            return _qlKhachSan.CHUCVUs.Where(u => u.TrangThai == 1).Select(v => new ChucVuDTO
            {
                MaCV = v.MaCV,
                TenCV = v.TenCV,
            }).ToList();
        }
    }
}
