﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class DichVuDAO
    {
        private QuanLyKhachSanEntities _qlKhachSan = new QuanLyKhachSanEntities();

        public List<DichVuDTO> LayDSDichVuDAO()
        {
            return _qlKhachSan.DICHVUs.Where(u => u.TrangThai == 1).Select(v => new DichVuDTO
            {
                MaDichVu = v.MaDichVu,
                LoaiDichVu = v.LoaiDichVu,
                DonGia = (int)v.DonGia,
            }).ToList();
        }
        public DichVuDTO LayDichVuTheoHoaDonDTO(int MaDichVu)
        {
            DICHVU dichVuEF = _qlKhachSan.DICHVUs.SingleOrDefault(u => u.MaDichVu == MaDichVu && u.TrangThai == 1);
            DichVuDTO dichVuDTO = new DichVuDTO
            {
                MaDichVu = dichVuEF.MaDichVu,
                LoaiDichVu = dichVuEF.LoaiDichVu,
                DonGia = dichVuEF.DonGia.Value
            };
            return dichVuDTO;
        }
        public int MaxMaDichVu()
        {
            return _qlKhachSan.DICHVUs.Max(u => u.MaDichVu);
        }
        public bool KiemTraTrungLap(int MaDichVu)
        {
            DICHVU dichVu = _qlKhachSan.DICHVUs.SingleOrDefault(u => u.MaDichVu == MaDichVu);
            return dichVu != null;
        }
        public bool KiemTraTrungLapTen(string LoaiDichVu)
        {
            DICHVU dichVu = _qlKhachSan.DICHVUs.SingleOrDefault(u => u.LoaiDichVu == LoaiDichVu);
            return dichVu != null;
        }
        public int ThemDichVu(DichVuDTO dichVuDTO)
        {
            try
            {
                DICHVU dichVuEF = new DICHVU
                {
                    MaDichVu = dichVuDTO.MaDichVu,
                    LoaiDichVu = dichVuDTO.LoaiDichVu,
                    DonGia = dichVuDTO.DonGia,
                    TrangThai = 1,
                };
                dichVuEF = _qlKhachSan.DICHVUs.Add(dichVuEF);
                _qlKhachSan.SaveChanges();

                return Convert.ToInt32(dichVuEF.MaDichVu);
            }
            catch (Exception e)
            {
                return 0;
            }
        }

        public int CapNhatDichVu(DichVuDTO dichVuDTO)
        {
            try
            {
                DICHVU dichVuEF = _qlKhachSan.DICHVUs.SingleOrDefault(u => u.MaDichVu == dichVuDTO.MaDichVu);
                dichVuEF.MaDichVu = dichVuDTO.MaDichVu;
                dichVuEF.LoaiDichVu = dichVuDTO.LoaiDichVu;
                dichVuEF.DonGia = dichVuDTO.DonGia;
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch (Exception e)
            {
                return 0;
            }
        }
        public int XoaDichVu(DichVuDTO dichVuDTO)
        {
            try
            {
                DICHVU dichVuEF = _qlKhachSan.DICHVUs.SingleOrDefault(u => u.MaDichVu == dichVuDTO.MaDichVu);
                dichVuEF.TrangThai = 0;
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
    }
}
