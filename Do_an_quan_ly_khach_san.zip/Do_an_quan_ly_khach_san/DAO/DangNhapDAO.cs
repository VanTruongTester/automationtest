﻿using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class DangNhapDAO
    {
        private QuanLyKhachSanEntities _qlKhachSan = new QuanLyKhachSanEntities();
        public NhanVienDTO DangNhapNhanVien(string tentk, string matkhau)
        {

            NHANVIEN nvET = _qlKhachSan.NHANVIENs.SingleOrDefault(u => u.TrangThai == 1 && u.MatKhau == matkhau && u.TenTK == tentk);
            if (nvET == null) return null;

            NhanVienDTO nvDTO = new NhanVienDTO()
            {
                MaNV = nvET.MaNV,
                HoTenNV = nvET.HoTenNV,
                DiaChi = nvET.DiaChi,
                GioiTinh = nvET.GioiTinh,
                MaCV = (int)nvET.MaCV,
                SDT = (int)nvET.SDT,
                TenTK = nvET.TenTK,

                MatKhau = nvET.MatKhau
            };
            return nvDTO;

        }

        public bool CheckedPhanQuyen(string tentk, string matkhau)
        {
            if (tentk == "admin" && matkhau == "1234")
                return true;
            else
                return false;
        }
    }
}
