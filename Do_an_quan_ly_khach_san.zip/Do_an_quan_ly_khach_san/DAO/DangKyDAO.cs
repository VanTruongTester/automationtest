﻿using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class DangKyDAO
    {
        private QuanLyKhachSanEntities _qlKhachSan = new QuanLyKhachSanEntities();
        public int MaxSoDK()
        {
            return _qlKhachSan.DANGKies.Max(u => u.SoDK);
        }
        public int MaxMP()
        {
            return _qlKhachSan.DANGKies.Max(u => u.MaPhong);
        }

        public bool KiemTraTrungLap(int SoDK)
        {
            DANGKY dangKy = _qlKhachSan.DANGKies.SingleOrDefault(u => u.SoDK == SoDK);
            return dangKy != null;
        }
        public int DangKy(DangKyDTO dangKy)
        {
            try
            {
                DANGKY dangKyEF = new DANGKY
                {
                    SoDK = dangKy.SoDK,
                    NgayDK = dangKy.NgayDK,
                    MaPhong = dangKy.MaPhong,
                    MaKH = dangKy.MaKH,
                    NgayGioDen = dangKy.NgayGioDen,
                    NgayGioDi = dangKy.NgayGioDi,
                    TrangThai = 1,
                };
                dangKyEF = _qlKhachSan.DANGKies.Add(dangKyEF);
                _qlKhachSan.SaveChanges();

                return dangKyEF.SoDK;
            }
            catch (Exception e)
            {
                return 0;
            }
        }
        public int Sua(DangKyDTO dangKyDTO)
        {
            try
            {
                PHONG phongEF = _qlKhachSan.PHONGs.SingleOrDefault(u => u.MaPhong == dangKyDTO.MaPhong);
                phongEF.TinhTrang = "Đang sử dụng";
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch (Exception e)
            {
                return 0;
            }
        }
    }
}
