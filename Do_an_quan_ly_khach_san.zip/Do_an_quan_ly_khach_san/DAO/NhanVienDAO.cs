﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
namespace DAO
{
    public class NhanVienDAO
    {
        private QuanLyKhachSanEntities _qlKhachSan = new QuanLyKhachSanEntities();
        public List<NhanVienDTO> LayDSNhanVienDTO()
        {
            return _qlKhachSan.NHANVIENs.Where(u => u.TrangThai == 1).Select(v => new NhanVienDTO
            {
                MaNV = v.MaNV,
                HoTenNV = v.HoTenNV,
                DiaChi = v.DiaChi,
                GioiTinh = v.GioiTinh,
                SDT = (int)v.SDT,
                MaCV = (int)v.MaCV,
                TenTK = v.TenTK,
                MatKhau = v.MatKhau,
            }).ToList();
        }
        public int MaxMaNV()
        {
            return _qlKhachSan.NHANVIENs.Max(u => u.MaNV);
        }
        public bool KiemTraNhanVienTrongHoaDon(int MaNV)
        {
            int dem = _qlKhachSan.HOADONs.Count(u => u.MaNV == MaNV && u.TrangThai == 1);
            if (dem == 0)
            {
                return false;
            }
            else if (dem >0)
            {
                return true;
            }
            return true;
        }
        public int ThemNhanVien(NhanVienDTO nhanVienDTO)
        {
            try
            {
                NHANVIEN nhanVienEF = new NHANVIEN
                {
                    MaNV = nhanVienDTO.MaNV,
                    HoTenNV = nhanVienDTO.HoTenNV,
                    DiaChi = nhanVienDTO.DiaChi,
                    GioiTinh = nhanVienDTO.GioiTinh,
                    SDT = nhanVienDTO.SDT,
                    MaCV = nhanVienDTO.MaCV,
                    TenTK = nhanVienDTO.TenTK,
                    MatKhau = nhanVienDTO.MatKhau,
                    TrangThai = 1,
                };
                nhanVienEF = _qlKhachSan.NHANVIENs.Add(nhanVienEF);
                _qlKhachSan.SaveChanges();

                return nhanVienEF.MaNV;
            }
            catch (Exception e)
            {
                return 0;
            }
        }
        public int CapNhatNhanVien(NhanVienDTO nhanVienDTO)
        {
            try
            {
                NHANVIEN nhanVienEF = _qlKhachSan.NHANVIENs.SingleOrDefault(u => u.MaNV == nhanVienDTO.MaNV);
                nhanVienEF.MaNV = nhanVienDTO.MaNV;
                nhanVienEF.HoTenNV = nhanVienDTO.HoTenNV;
                nhanVienEF.DiaChi = nhanVienDTO.DiaChi;
                nhanVienEF.GioiTinh = nhanVienDTO.GioiTinh;
                nhanVienEF.SDT = nhanVienDTO.SDT;
                nhanVienEF.MaCV = nhanVienDTO.MaCV;
                nhanVienEF.TenTK = nhanVienDTO.TenTK;
                nhanVienEF.MatKhau = nhanVienDTO.MatKhau;
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch (Exception e)
            {
                return 0;
            }
        }
        public int XoaNhanVien(NhanVienDTO nhanVienDTO)
        {
            try
            {
                NHANVIEN nhanVienEF = _qlKhachSan.NHANVIENs.SingleOrDefault(u => u.MaNV == nhanVienDTO.MaNV);
                nhanVienEF.TrangThai = 0;
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

    }
}
