﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
namespace DAO
{
   public class KhachHangDAO
    {
        private QuanLyKhachSanEntities _qlKhachSan = new QuanLyKhachSanEntities();
        public List<KhachHangDTO> LayDSKhachHangDTO()
        {
            return _qlKhachSan.KHACHHANGs.Where(u => u.TrangThai == 1).Select(v => new KhachHangDTO
            {
                MaKH = v.MaKH,
                HoTenKH = v.HoTenKH,
                SDT = (int)v.SDT,
                GioiTinh = v.GioiTinh,
                NgaySinh = v.NgaySinh.Value,
                Email = v.Email,
                CMND = v.CMND.Value,
                QuocTich = v.QuocTich
            }).ToList();
        }
        public KhachHangDTO LayKhachHangTheoHoaDonDTO(string MaKH)
        {
            KHACHHANG khachHangEF = _qlKhachSan.KHACHHANGs.SingleOrDefault(u => u.MaKH == MaKH && u.TrangThai == 1);
            KhachHangDTO khachHangDTO = new KhachHangDTO
            {
                MaKH = khachHangEF.MaKH,
                HoTenKH = khachHangEF.HoTenKH,
                SDT = (int)khachHangEF.SDT,
                GioiTinh = khachHangEF.GioiTinh,
                NgaySinh = khachHangEF.NgaySinh.Value,
                Email = khachHangEF.Email,
                CMND = khachHangEF.CMND.Value,
                QuocTich = khachHangEF.QuocTich,
            };
            return khachHangDTO;
        }
       
        public int MaxMaKH()
        {
            return Convert.ToInt32(_qlKhachSan.KHACHHANGs.Max(u => u.MaKH));
        }
        public int ThemKhachHang(KhachHangDTO khachHangDTO)
        {
            try
            {
                KHACHHANG khachHangEF = new KHACHHANG
                {
                    MaKH = khachHangDTO.MaKH,
                    HoTenKH = khachHangDTO.HoTenKH,
                    SDT = khachHangDTO.SDT,
                    GioiTinh = khachHangDTO.GioiTinh,
                    NgaySinh = khachHangDTO.NgaySinh,
                    Email = khachHangDTO.Email,
                    CMND = khachHangDTO.CMND,
                    QuocTich = khachHangDTO.QuocTich,
                    TrangThai = 1,
                };
                khachHangEF = _qlKhachSan.KHACHHANGs.Add(khachHangEF);
                _qlKhachSan.SaveChanges();
                int themKhachHang = int.Parse(khachHangEF.MaKH);
                return themKhachHang;
            }
            catch (Exception e)
            {
                return 0;
            }
        }
        public int CapNhatKhachHang(KhachHangDTO khachHangDTO)
        {
            try
            {
                KHACHHANG khachHangEF = _qlKhachSan.KHACHHANGs.SingleOrDefault(u => u.MaKH == khachHangDTO.MaKH);

                khachHangEF.HoTenKH = khachHangDTO.HoTenKH;
                khachHangEF.SDT = khachHangDTO.SDT;
                khachHangEF.GioiTinh = khachHangDTO.GioiTinh;
                khachHangEF.NgaySinh = khachHangDTO.NgaySinh;
                khachHangEF.Email = khachHangDTO.Email;
                khachHangEF.CMND = khachHangDTO.CMND;
                khachHangEF.QuocTich = khachHangDTO.QuocTich;
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch (Exception e)
            {
                return 0;
            }
        }
        public int XoaKhachHang(KhachHangDTO khachHangDTO)
        {
            try
            {
                KHACHHANG khachHangEF = _qlKhachSan.KHACHHANGs.SingleOrDefault(u => u.MaKH == khachHangDTO.MaKH);
                khachHangEF.TrangThai = 0;
                _qlKhachSan.SaveChanges();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
    }
}
