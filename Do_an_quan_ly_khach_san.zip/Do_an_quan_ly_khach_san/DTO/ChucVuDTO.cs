﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class ChucVuDTO
    {
         private int _maCV;
        private string _tenCV;
        public int MaCV
        {
            get { return _maCV; }
            set { _maCV = value; }
        }
        public string TenCV
        {
            get { return _tenCV; }
            set { _tenCV = value; }
        }
        public ChucVuDTO()
        {
            this.MaCV = 0;
            this.TenCV = string.Empty;
        }
        public ChucVuDTO(int MaCV, string TenCV)
        {
            this.MaCV = MaCV;
            this.TenCV = TenCV;
        }
    }
}
