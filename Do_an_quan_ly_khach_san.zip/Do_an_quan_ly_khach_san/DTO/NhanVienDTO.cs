﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class NhanVienDTO
    {
        private int _maNV;
        private string _hoTenNV;
        private string _diaChi;
        private string _gioiTinh;
        private int _sdt;
        private int _maCV;
        private string _tenTK;
        private string _matKhau;
        public int MaNV
        {
            get { return _maNV; }
            set { _maNV = value; }
        }
        public string HoTenNV
        {
            get { return _hoTenNV; }
            set { _hoTenNV = value; }
        }
        public string DiaChi
        {
            get { return _diaChi; }
            set { _diaChi = value; }
        }
        public string GioiTinh
        {
            get { return _gioiTinh; }
            set { _gioiTinh = value; }
        }
        public int SDT
        {
            get { return _sdt; }
            set { _sdt = value; }
        }
        public int MaCV
        {
            get { return _maCV; }
            set { _maCV = value; }
        }
        public string TenTK
        {
            get { return _tenTK; }
            set { _tenTK = value; }
        }
        public string MatKhau
        {
            get { return _matKhau; }
            set { _matKhau = value; }
        }
        public NhanVienDTO()
        {
            this.MaNV = 0;
            this.HoTenNV = string.Empty;
            this.DiaChi = string.Empty;
            this.GioiTinh = string.Empty;
            this.SDT = 0;
            this.MaCV = 0;
            this.TenTK = string.Empty;
            this.MatKhau = string.Empty;
        }
        public NhanVienDTO(int MaNV, string HoTenNV, string DiaChi, string GioiTinh, int SDT, int MaCV, string TenTK, string MatKhau)
        {
            this.MaNV = MaNV;
            this.HoTenNV = HoTenNV;
            this.DiaChi = DiaChi;
            this.GioiTinh = GioiTinh;
            this.SDT = SDT;
            this.MaCV = MaCV;
            this.TenTK = TenTK;
            this.MatKhau = MatKhau;
        }
    }
}
