﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class PhongDTO
    {
        private int _maPhong;
        private int _gia;
        private string _maLoaiPhong;
        private string _tenLoaiPhong;
        private string _tinhTrang;
        public int MaPhong
        {
            get { return _maPhong; }
            set { _maPhong = value; }
        }
        public int Gia
        {
            get { return _gia; }
            set { _gia = value; }
        }
        public string MaLoaiPhong
        {
            get { return _maLoaiPhong; }
            set { _maLoaiPhong = value; }
        }
        public string TinhTrang
        {
            get { return _tinhTrang; }
            set { _tinhTrang = value; }
        }
        public PhongDTO()
        {
            this.MaPhong = 0;
            this.Gia = 0;
            this.MaLoaiPhong = string.Empty;
            this.TinhTrang = string.Empty;
        }
        public PhongDTO(int MaPhong, int Gia, String MaLoaiPhong, string TinhTrang)
        {
            this.MaPhong = MaPhong;
            this.Gia = Gia;
            this.MaLoaiPhong = MaLoaiPhong;
            this.TinhTrang = TinhTrang;
        }
        public string TenLoaiPhong
        {
            get { return _tenLoaiPhong; }
            set { _tenLoaiPhong = value; }
        }
    }


}

