﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class LoaiPhongDTO
    {
        private string _maLoaiPhong;
        private string _tenLoaiPhong;
        public string MaLoaiPhong
        {
            get { return _maLoaiPhong; }
            set { _maLoaiPhong = value; }
        }
        public string TenLoaiPhong
        {
            get { return _tenLoaiPhong; }
            set { _tenLoaiPhong = value; }
        }
        public LoaiPhongDTO()
        {
            this.MaLoaiPhong = string.Empty;
            this.TenLoaiPhong = string.Empty;
        }
        public LoaiPhongDTO(string MaLoaiPhong, string TenLoaiPhong)
        {
            this.MaLoaiPhong = MaLoaiPhong;
            this.TenLoaiPhong = TenLoaiPhong;
        }
    }
}
