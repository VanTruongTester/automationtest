﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DichVuDTO
    {
        private int _maDichVu;
        private string _loaiDichVu;
        public int _donGia;
        public int MaDichVu
        {
            get { return _maDichVu; }
            set { _maDichVu = value; }
        }
        public string LoaiDichVu
        {
            get { return _loaiDichVu; }
            set { _loaiDichVu = value; }
        }
        public int DonGia
        {
            get { return _donGia; }
            set { _donGia = value; }
        }
        public DichVuDTO()
        {
            this.MaDichVu = 0;
            this.LoaiDichVu = string.Empty;
            this.DonGia = 0;
        }
        public DichVuDTO(int MaDichVu, string LoaiDichVu, int DonGia)
        {
            this.MaDichVu = MaDichVu;
            this.LoaiDichVu = LoaiDichVu;
            this.DonGia = DonGia;
        }
    }
}
