﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
   public class Constants
    {

        public static string MESSAGE_TITLE = "Thông báo";
        public static string ERR_REQUIRED = "Vui lòng điền đầy đủ thông tin!";
        public static string ERR_CHOOSE_DELETE = "Vui lòng chọn thông tin cần xóa";
        public static string SURE_DELETE_ROOM = "Bạn có chắc chắn muốn xóa phòng này không?";
        public static string SURE_DELETE_STAFF = "Bạn có chắc chắn muốn xóa nhân viên này không?";
        public static string SURE_DELETE_CUSTOMER = "Bạn có chắc chắn muốn xóa khách hàng này không?";
        public static string SURE_DELETE_BILL = "Bạn có chắc chắn muốn xóa hóa đơn này không?";
        public static string SURE_DELETE_REGI = "Bạn có chắc chắn muốn xóa bản đăng ký này không?";
        public static string SURE_PAY_BILL = "Bạn có chắc chắn muốn thanh hóa đơn này không?";
        public static string SURE_DELETE_SERVICE = "Bạn có chắc chắn muốn xóa dịch vụ này không?";
        public static string ERR_DATE = "Ngày sinh phải nhỏ hơn ngày hiện tại!";
        public static string DAY_RECE_NOT_EQUAL_DAY_NOW = "Ngày nhận không được nhỏ hơn ngày hiện tại!";
        public static string DAY_PAY_NOT_EQUAL_DAY_REGI = "Ngày trả không được nhỏ hơn ngày đăng nhận!";
        public static string DAY_RECE_NOT_EQUAL_DAY_NOW_QLDK = "Ngày giờ đến không được nhỏ hơn ngày hiện tại";
        public static string ERR_DATE_TIME = "Ngày giờ không hợp lệ vui lòng kiểm tra lại!";
        public static string ERR_DATE_TIME_QLDK = "Ngày đi không được nhỏ hơn ngày đến";
        public static string ERR_ACC_PASS_REQUIRED = "Chưa nhập tên tài khoản hoặc mặt khẩu!";
        public static string ERR_EMAIL_FORMAT = "Email chưa đúng định dạng";
        public static string NO_SPACE = "Không được sử dụng khoảng trắng";
        public static string PRICE = "Đơn giá không được nhỏ hơn, bằng 0 hoặc lớn hơn 1000000";
        public static string PRICE_PHONG = "Đơn giá không được nhỏ hơn, bằng 0 hoặc lớn hơn 10000000";
        public static string STATUS_PHONG = "Tình trạng phòng phải trống";
        public static string NUMBER = "Số điện thoại không được nhỏ hơn 10 số";
        public static string IDENTITY_CARD = "Chứng minh nhân dân không được nhỏ hơn 9 số";
        public static string ERR_PASSWORD = "Mật khẩu không được nhỏ hơn 6 ký tư hoặc lớn 10 ký tự";
        public static string EXIST_PASS_ROOM = "Mã phòng đã tồn tại!";
        public static string EXIST_PASS_STAFF = "Mã nhân viên đã tồn tại!";
        public static string EXIST_PASS_CUSTOMER = "Mã khách hàng đã tồn tại!";
        public static string EXIST_PASS_BILL = "Mã hóa đơn đã tồn tại!";
        public static string EXIST_PASS_SERVICE = "Mã dịch vụ đã tồn tại";
        public static string EXIST_PASS_SERVICE_NAME = "Loại dịch vụ đã tồn tại";
        public static string STAFF_EXIST_BILL = "Nhân viên đang tồn tại trong hóa đơn!";
        public static string CHOOSE_DELETE = "Bạn chưa chọn dịch vụ cần xóa!";
        public static string LOGIN_SUCCESS = "Đăng nhập thành công";
        public static string LOGIN_FAIL = "Đăng nhập thất bại";
        public static string UPADATE_ROOM_SUCCESS = "Cập nhật phòng không thành công!";
        public static string ERR_ACCOUNT_FORMAT = "Tên tài khoản không đúng định dạng";
        public static string LOGIN = "Đăng nhập";
        public static string LOGIN_NAME = "Tên đăng nhập";
        public static string PASSWORD = "Mật Khẩu";
        public static string HAVE_FORM = "form đã có sẵn";
        public static string ADD_SUCCESS = "Thêm thành công!";
        public static string ADD_FAIL = "Thêm thất bại!";
        public static string UPADATE_SUCCESS = "Cập nhật thành công!";
        public static string UPADATE_FAIL = "Cập nhật thất bại!";
        public static string DELETE_SUCCESS = "Xóa thành công!";
        public static string DELETE_FAIL = "Xóa thất bại!";
        public static string PAY_SUCCESS = "Thanh toán thành công!";
        public static string PAY_FAIL = "Thanh toán thất bại!";
        public static string REGI_SUCCESS = "Đăng ký thành công!";
        public static string BOOK_SUCCESS = "Đặt thành công!";
        public static string BOOK_FAIL = "Đặt thất bại!";
        public static string BOY = "Nam";
        public static string GIRL = "Nữ";
        public static string DATETIME = "dd/MM/yyyy";
        public static int DON_GIA_MIN = 0;
        public static int DON_GIA_MAX = 10000000;
        public static int DON_GIA_PHONG_MAX = 10000000;
        public static long SO_MAX = 999999999;
        public static int SO_MIN = 99999999;
        public static long CMND_MIN = 9;
        public static int KY_TU_MAX = 10;
        public static int KY_TU_MIN = 6;

        #region button
        public static string ADD = "Thêm";
        public static string UPDATE = "Cập nhật";
        public static string DELETE = "Xóa";
        public static string REFRESH = "Làm mới";
        public static string BACK = "Quay lại";
        public static string CREATE_PASS_ROOM = "Tạo mã phòng";
        public static string BOOK = "Đặt thành công";
        public static string REGI = "Đăng ký thành công";
        public static string CREATE_NUM_REGI = "Tạo Số Đăng Ký";
        public static string SEEN_REPORT = "Xem Báo Cáo";
        public static string EXIT = "Thoát";
        #endregion
    }
}
