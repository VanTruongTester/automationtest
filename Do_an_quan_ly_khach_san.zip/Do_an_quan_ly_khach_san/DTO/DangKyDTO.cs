﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DangKyDTO
    {
        private int _soDK;
        private DateTime _ngayDK;
        private int _maPhong;
        private string _maKH;
        private DateTime _ngayGioDen;
        private DateTime _ngayGioDi;

        public int SoDK
        {
            get { return _soDK; }
            set { _soDK = value; }
        }
        public DateTime NgayDK
        {
            get { return _ngayDK; }
            set { _ngayDK = value; }
        }
        public int MaPhong
        {
            get { return _maPhong; }
            set { _maPhong = value; }
        }
        public string MaKH
        {
            get { return _maKH; }
            set { _maKH = value; }
        }
        public DateTime NgayGioDen
        {
            get { return _ngayGioDen; }
            set { _ngayGioDen = value; }
        }
        public DateTime NgayGioDi
        {
            get { return _ngayGioDi; }
            set { _ngayGioDi = value; }
        }
        public DangKyDTO()
        {
            this.SoDK = 0;
            this.NgayDK = DateTime.Now;
            this.MaPhong = 0;
            this.MaKH = string.Empty;
            this.NgayGioDen = DateTime.Now;
            this.NgayGioDi = DateTime.Now;
        }
        public DangKyDTO(int SoDK, DateTime NgayDK, int MaPhong, string MaKH, DateTime NgayGioDen, DateTime NgayGioDi)
        {
            this.SoDK = SoDK;
            this.NgayDK = NgayDK;
            this.MaPhong = MaPhong;
            this.MaKH = MaKH;
            this.NgayGioDen = NgayGioDen;
            this.NgayGioDi = NgayGioDi;
        }
    }
}
