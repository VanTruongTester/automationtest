﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class KhachHangDTO
    {
        private string _maKH;
        private string _hoTenKH;
        private int _sdt;
        private string _gioiTinh;
        private DateTime _ngaySinh;
        private string _email;
        private int _cmnd;
        private string _quocTich;
        public string MaKH
        {
            get { return _maKH; }
            set { _maKH = value; }
        }
        public string HoTenKH
        {
            get { return _hoTenKH; }
            set { _hoTenKH = value; }
        }
        public int SDT
        {
            get { return _sdt; }
            set { _sdt = value; }
        }
        public string GioiTinh
        {
            get { return _gioiTinh; }
            set { _gioiTinh = value; }
        }
        public DateTime NgaySinh
        {
            get { return _ngaySinh; }
            set { _ngaySinh = value; }
        }
        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        public int CMND
        {
            get { return _cmnd; }
            set { _cmnd = value; }
        }
        public string QuocTich
        {
            get { return _quocTich; }
            set { _quocTich = value; }
        }
        public KhachHangDTO()
        {
            this.MaKH = string.Empty;
            this.HoTenKH = string.Empty;
            this.SDT = 0;
            this.GioiTinh = string.Empty;
            this.NgaySinh = DateTime.Now;
            this.Email = Email;
            this.CMND = CMND;
            this.QuocTich = QuocTich;
        }
        public KhachHangDTO(string MaKH, string HoTenKH, int SDT, string GioiTinh, DateTime NgaySinh, string Email, int CMND, string QuocTich)
        {
            this.MaKH = MaKH;
            this.HoTenKH = HoTenKH;
            this.SDT = SDT;
            this.GioiTinh = GioiTinh;
            this.NgaySinh = NgaySinh;
            this.Email = Email;
            this.CMND = CMND;
            this.QuocTich = QuocTich;
        }
    
    }
}
