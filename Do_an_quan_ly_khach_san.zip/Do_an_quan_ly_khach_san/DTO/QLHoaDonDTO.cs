﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class QLHoaDonDTO
    {
        private int _maHD;
        private string _tenHD;
        private int _maNV;
        private string _hoTenNV;
        private string _maKH;
        private string _hoTenKH;
        private DateTime _ngayLapHD;
        private int _tongTien;
        private int _maPhong;
        private int _maDichVu;
        public int MaHD
        {
            get { return _maHD; }
            set { _maHD = value; }
        }
        public string TenHD
        {
            get { return _tenHD; }
            set { _tenHD = value; }
        }
        public int MaNV
        {
            get { return _maNV; }
            set { _maNV = value; }
        }
        public string HoTenNV
        {
            get { return _hoTenNV; }
            set { _hoTenNV = value; }
        }
        public string MaKH
        {
            get { return _maKH; }
            set { _maKH = value; }
        }
        public string HoTenKH
        {
            get { return _hoTenKH; }
            set { _hoTenKH = value; }
        }
        public DateTime NgayLapHD
        {
            get { return _ngayLapHD; }
            set { _ngayLapHD = value; }
        }
        public int TongTien
        {
            get { return _tongTien; }
            set { _tongTien = value; }
        }
        public int MaPhong
        {
            get { return _maPhong; }
            set { _maPhong = value; }
        }
        public QLHoaDonDTO()
        {
            this.MaHD = 0;
            this.TenHD = string.Empty;
            this.MaNV = 0;
            this.HoTenNV = string.Empty;
            this.MaKH = string.Empty;
            this.HoTenKH = string.Empty;
            this.NgayLapHD = DateTime.Now;
            this.TongTien = 0;
            this._maPhong = 0;
        }
        public QLHoaDonDTO(int MaHD, string TenHD, int MaNV, string HoTenNV, string MaKH, string HoTenKH, DateTime NgayLapHD, int TongTien, int MaPhong)
        {
            this.MaHD = MaHD;
            this.TenHD = TenHD;
            this.MaNV = MaNV;
            this.HoTenNV = HoTenNV;
            this.MaKH = MaKH;
            this.HoTenKH = HoTenKH;
            this.NgayLapHD = NgayLapHD;
            this.TongTien = TongTien;
            this.MaPhong = MaPhong;
        }
    }
}
