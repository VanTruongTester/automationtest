﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public static class NhanVienHienHanhDTO
    {
        private static NhanVienDTO _nhanVienHienHanhDTO;
        public static NhanVienDTO NhanVienHHDTO
        {
            get { return _nhanVienHienHanhDTO; }
            set { _nhanVienHienHanhDTO = value; }
        }
    }
}
