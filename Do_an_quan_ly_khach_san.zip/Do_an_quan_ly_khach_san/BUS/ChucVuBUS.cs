﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;
namespace BUS
{
    public class ChucVuBUS
    {
        private ChucVuDAO _chucVuDAO = new ChucVuDAO();
        public List<ChucVuDTO> LayDSChucVu()
        {
            return _chucVuDAO.LayDSChuVuDTO();
        }
    }
}
