﻿using DAO;
using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public class QLHoaDonBUS
    {
        private QLHoaDonDAO _qlHoaDonDAO = new QLHoaDonDAO();
        public List<QLHoaDonDTO> LayDSHoaDon()
        {
            return _qlHoaDonDAO.LayDSHoaDonDAO();
        }
        public List<QLHoaDonDTO> LayDSKhachHangTheoNgay(DateTime ngayLapHD)
        {
            return _qlHoaDonDAO.LayDSKhachHangTheoNgay(ngayLapHD);
        }
        public bool KiemTraTrungLap(int MaHD)
        {
            return _qlHoaDonDAO.KiemTraTrungLap(MaHD);
        }
        public int XoaHoaDon(QLHoaDonDTO hoaDonDTO)
        {
            return _qlHoaDonDAO.XoaHoaDon(hoaDonDTO);
        }
        public int MaxMaHD()
        {
            return _qlHoaDonDAO.MaxMaHD();
        }
        public int DatNgay(QLHoaDonDTO qlHoaDonDTO)
        {
            return _qlHoaDonDAO.DatNgay(qlHoaDonDTO);
        }
    }
}
