﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;
namespace BUS
{
    public class LoaiPhongBUS
    {
        private LoaiPhongDAO loaiPhongDAO = new LoaiPhongDAO();
        public List<LoaiPhongDTO> LayDSLoaiPhong()
        {
            return loaiPhongDAO.LayDSLoaiPhong();
        }
    }
}
