﻿using DAO;
using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public class DangKyBUS
    {
        private DangKyDAO dangKyDAO = new DangKyDAO();
        public int MaxSoDK()
        {
            return dangKyDAO.MaxSoDK();
        }
        public int MaxMP()
        {
            return dangKyDAO.MaxMP();
        }
        public bool KiemTraTrungLap(int SoDK)
        {
            return dangKyDAO.KiemTraTrungLap(SoDK);
        }
        public int DangKy(DangKyDTO dangKy)
        {
            return dangKyDAO.DangKy(dangKy);
        }
        public int Sua(DangKyDTO dangKy)
        {
            return dangKyDAO.Sua(dangKy);
        }
    }
}
