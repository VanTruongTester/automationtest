﻿using DAO;
using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
    public class DichVuBUS
    {
        private DichVuDAO _dichVuDAO = new DichVuDAO();

        public List<DichVuDTO> LayDSDichVu()
        {
            return _dichVuDAO.LayDSDichVuDAO();
        }
        public DichVuDTO LayDichVuTheoHoaDon(int MaDichVu)
        {
            return _dichVuDAO.LayDichVuTheoHoaDonDTO(MaDichVu);
        }
        public int MaxMaDichVu()
        {
            return _dichVuDAO.MaxMaDichVu();
        }
        public bool KiemTraTrungLap(int MaDichVu)
        {
            return _dichVuDAO.KiemTraTrungLap(MaDichVu);
        }
        public bool KiemTraTrungLapTen(string LoaiDichVu)
        {
            return _dichVuDAO.KiemTraTrungLapTen(LoaiDichVu);
        }
        public int ThemDichVu(DichVuDTO dichVuDTO)
        {
            return _dichVuDAO.ThemDichVu(dichVuDTO);
        }
        public int CapNhatDichVu(DichVuDTO dichVuDTO)
        {
            return _dichVuDAO.CapNhatDichVu(dichVuDTO);
        }
        public int XoaDichVu(DichVuDTO dichVuDTO)
        {
            return _dichVuDAO.XoaDichVu(dichVuDTO);
        }
    }
}
