﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;
using System.Text.RegularExpressions;
namespace BUS
{
    public class KhachHangBUS
    {
        private KhachHangDAO _khachHangDAO = new KhachHangDAO();
        public List<KhachHangDTO> LayDSKhachHang()
        {
            return _khachHangDAO.LayDSKhachHangDTO();
        }
        public KhachHangDTO LayKhachHangTheoHoaDon(string MaKH)
        {
            return _khachHangDAO.LayKhachHangTheoHoaDonDTO(MaKH);
        }
        public bool KiemTraDinhDangEmail(string tentk)
        {
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(tentk);
            return match.Success;
        }
       
        public int MaxMaKH()
        {
            return _khachHangDAO.MaxMaKH();
        }
        public int ThemKhachHang(KhachHangDTO khachHangDTO)
        {
            return _khachHangDAO.ThemKhachHang(khachHangDTO);
        }
        public int CapNhatKhachHang(KhachHangDTO khachHangDTO)
        {
            return _khachHangDAO.CapNhatKhachHang(khachHangDTO);
        }
        public int XoaKhachHang(KhachHangDTO khachHangDTO)
        {
            return _khachHangDAO.XoaKhachHang(khachHangDTO);
        }
    }
}
