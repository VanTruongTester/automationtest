﻿using DAO;
using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BUS
{
    public class DangNhapBUS
    {
        private DangNhapDAO _dangNhapDAO = new DangNhapDAO();
        public bool KiemTraDinhDangEmail(string tentk)
        {
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(tentk);
            return match.Success;
        }
        public NhanVienDTO DangNhapNhanVien(string tentk, string matkhau)
        {
            return _dangNhapDAO.DangNhapNhanVien(tentk, matkhau);
        }
        public bool CheckedPhanQuyen(string tentk, string matkhau)
        {
            return _dangNhapDAO.CheckedPhanQuyen(tentk, matkhau);
        }
    }
}
