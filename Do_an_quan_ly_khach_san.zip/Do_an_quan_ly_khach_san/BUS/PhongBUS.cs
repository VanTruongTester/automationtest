﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAO;

namespace BUS
{
    public class PhongBUS
    {
         private PhongDAO _phongDAO = new PhongDAO();
        public List<PhongDTO> LayDSPhong()
        {
            return _phongDAO.LayDSPhong();
        }
        public PhongDTO LapPhongTheoHoaDon(int MaPhong)
        {
            return _phongDAO.LayPhongTheoHoaDonDTO(MaPhong);
        }
        public bool KiemTraTrungLap(int MaPhong)
        {
            return _phongDAO.KiemTraTrungLap(MaPhong);
        }
        public int MaxMaPhong()
        {
            return _phongDAO.MaxMaPhong();
        }
        public int ThemPhong(PhongDTO phong)
        {
            return _phongDAO.ThemPhong(phong);
        }
        public int CapNhatPhong(PhongDTO phong)
        {
            return _phongDAO.CapNhatPhong(phong);
        }
        public int XoaPhong(PhongDTO phong)
        {
            return _phongDAO.XoaPhong(phong);
        }
    }
}
