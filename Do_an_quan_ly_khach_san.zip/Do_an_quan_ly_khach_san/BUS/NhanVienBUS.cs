﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using DTO;
using System.Text.RegularExpressions;
namespace BUS
{
   public class NhanVienBUS
    {
        private NhanVienDAO _nhanVienDAO = new NhanVienDAO();
        public List<NhanVienDTO> LayDSNhanVien()
        {
            return _nhanVienDAO.LayDSNhanVienDTO();
        }
        public int MaxMaNV()
        {
            return _nhanVienDAO.MaxMaNV();
        }
   
        public bool KiemTraDinhDangEmail(string tentk)
        {
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(tentk);
            return match.Success;
        }
        public bool KiemTraNhanVienTrongHoaDon(int MaNV)
        {
            return _nhanVienDAO.KiemTraNhanVienTrongHoaDon(MaNV);
        }
        public int ThemNhanVien(NhanVienDTO nhanVienDTO)
        {
            return _nhanVienDAO.ThemNhanVien(nhanVienDTO);
        }
        public int CapNhatNhanVien(NhanVienDTO nhanVienDTO)
        {
            return _nhanVienDAO.CapNhatNhanVien(nhanVienDTO);
        }
        public int XoaNhanVien(NhanVienDTO nhanVienDTO)
        {
            return _nhanVienDAO.XoaNhanVien(nhanVienDTO);
        }
       
    }
    }
