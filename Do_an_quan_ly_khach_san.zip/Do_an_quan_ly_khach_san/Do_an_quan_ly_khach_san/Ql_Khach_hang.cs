﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DTO;
using BUS;
namespace Do_an_quan_ly_khach_san
{
    public partial class Ql_Khach_hang : Form
    {
        private KhachHangDTO _khachHangDTO = new KhachHangDTO();
        private KhachHangBUS _khachHangBUS = new KhachHangBUS();
        public Ql_Khach_hang()
        {
            InitializeComponent();
            dgvQLKhachHang.AutoGenerateColumns = false;
        }

        private void btnQuayLai_Click(object sender, EventArgs e)
        {
            Trang_chu f = new Trang_chu(true);
            this.Hide();
            f.ShowDialog();
        }

        private void Ql_Khach_hang_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void btnTao_Click(object sender, EventArgs e)
        {
            txtMaKH.Text = (_khachHangBUS.MaxMaKH() + 1).ToString();
        }

        private void Ql_Khach_hang_Load(object sender, EventArgs e)
        {
            radNam.Checked = true;
            txtMaKH.Enabled = false;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            dgvQLKhachHang.DataSource = _khachHangBUS.LayDSKhachHang();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaKH.Text) || string.IsNullOrEmpty(txtSĐT.Text) || string.IsNullOrEmpty(txtHoTenKH.Text)
             || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtCMND.Text) || string.IsNullOrEmpty(txtQuocTich.Text))
            {
                MessageBox.Show(Constants.ERR_REQUIRED, Constants.MESSAGE_TITLE, MessageBoxButtons.OK);
            }
            else if (string.IsNullOrWhiteSpace(txtHoTenKH.Text) || string.IsNullOrWhiteSpace(txtSĐT.Text) || string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(txtCMND.Text) || string.IsNullOrWhiteSpace(txtQuocTich.Text))
            {
                MessageBox.Show(Constants.NO_SPACE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtHoTenKH.Text = string.Empty;
                txtSĐT.Text = string.Empty;
                txtEmail.Text = string.Empty;
                txtCMND.Text = string.Empty;
                txtQuocTich.Text = string.Empty;
            }
            else if (Convert.ToInt32(txtSĐT.Text) <= Constants.SO_MIN)
            {
                MessageBox.Show(Constants.NUMBER, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSĐT.Text = string.Empty;
                return;
            }
            else if (Convert.ToInt32(txtCMND.Text) < Constants.CMND_MIN)
            {
                MessageBox.Show(Constants.IDENTITY_CARD, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCMND.Text = string.Empty;
                return;
            }
            else
            {
                 if (!_khachHangBUS.KiemTraDinhDangEmail(txtEmail.Text))
                {
                    MessageBox.Show(Constants.ERR_ACCOUNT_FORMAT, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtEmail.Text = string.Empty;
                    return;
                }
                else
                {
                    if (dtpNgaySinh.Value < DateTime.Now)
                    {
                        KhachHangDTO khachHangDTO = new KhachHangDTO
                        {
                            MaKH = txtMaKH.Text,
                            HoTenKH = txtHoTenKH.Text,
                            GioiTinh = radNam.Checked ? Constants.BOY : Constants.GIRL,
                            SDT = Convert.ToInt32(txtSĐT.Text),
                            NgaySinh = dtpNgaySinh.Value,
                            Email = txtEmail.Text,
                            CMND = Convert.ToInt32(txtCMND.Text),
                            QuocTich = txtQuocTich.Text
                        };
                        int result = _khachHangBUS.ThemKhachHang(khachHangDTO);
                        if (result > 0)
                        {
                            MessageBox.Show(Constants.ADD_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            dgvQLKhachHang.DataSource = _khachHangBUS.LayDSKhachHang();
                            txtMaKH.Text = string.Empty;
                            txtSĐT.Text = string.Empty;
                            radNam.Checked = true;
                            txtHoTenKH.Text = string.Empty;
                            dtpNgaySinh.Value = DateTime.Now;
                            txtEmail.Text = string.Empty;
                            txtCMND.Text = string.Empty;
                            txtQuocTich.Text = string.Empty;
                            txtMaKH.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show(Constants.ADD_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show(Constants.ERR_DATE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        

        private void btnSua_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txtSĐT.Text) || string.IsNullOrEmpty(txtHoTenKH.Text)
            || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtCMND.Text) || string.IsNullOrEmpty(txtQuocTich.Text))
            {
                MessageBox.Show(Constants.ERR_REQUIRED, Constants.MESSAGE_TITLE, MessageBoxButtons.OK);
            }
            else if (string.IsNullOrWhiteSpace(txtHoTenKH.Text) || string.IsNullOrWhiteSpace(txtSĐT.Text) || string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(txtCMND.Text) || string.IsNullOrWhiteSpace(txtQuocTich.Text))
            {
                MessageBox.Show(Constants.NO_SPACE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtHoTenKH.Text = string.Empty;
                txtSĐT.Text = string.Empty;
                txtEmail.Text = string.Empty;
                txtCMND.Text = string.Empty;
                txtQuocTich.Text = string.Empty;
            }
            else if (Convert.ToInt32(txtSĐT.Text) > Constants.SO_MAX || Convert.ToInt32(txtSĐT.Text) <= Constants.SO_MIN)
            {
                MessageBox.Show(Constants.NUMBER, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSĐT.Text = string.Empty;
                return;
            }
            else if (Convert.ToInt32(txtCMND.Text) < Constants.CMND_MIN)
            {
                MessageBox.Show(Constants.IDENTITY_CARD, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCMND.Text = string.Empty;
                return;
            }
            else
            {
                if (!_khachHangBUS.KiemTraDinhDangEmail(txtEmail.Text))
                {
                    MessageBox.Show(Constants.ERR_ACCOUNT_FORMAT, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtEmail.Text = string.Empty;
                    return;
                }
                else if (dtpNgaySinh.Value < DateTime.Now)
                {
                    KhachHangDTO khachHangDTO = new KhachHangDTO
                    {

                        MaKH = txtMaKH.Text,
                        HoTenKH = txtHoTenKH.Text,
                        GioiTinh = radNam.Checked ? Constants.BOY : Constants.GIRL,
                        SDT = Convert.ToInt32(txtSĐT.Text),
                        NgaySinh = dtpNgaySinh.Value,
                        Email = txtEmail.Text,
                        CMND = Convert.ToInt32(txtCMND.Text),
                        QuocTich = txtQuocTich.Text
                    };
                    int result = _khachHangBUS.CapNhatKhachHang(khachHangDTO);
                    if (result > 0)
                    {
                        MessageBox.Show(Constants.UPADATE_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvQLKhachHang.DataSource = _khachHangBUS.LayDSKhachHang();
                        txtMaKH.Text = string.Empty;
                        txtSĐT.Text = string.Empty;
                        radNam.Checked = true;
                        txtHoTenKH.Text = string.Empty;
                        dtpNgaySinh.Value = DateTime.Now;
                        txtEmail.Text = string.Empty;
                        txtCMND.Text = string.Empty;
                        txtQuocTich.Text = string.Empty;
                    }
                    else
                    {
                        MessageBox.Show(Constants.UPADATE_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(Constants.ERR_DATE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show(Constants.SURE_DELETE_CUSTOMER, Constants.MESSAGE_TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlr == DialogResult.Yes)
            {
                KhachHangDTO khachHangDTO = new KhachHangDTO
                {
                    MaKH = txtMaKH.Text,
                    HoTenKH = txtHoTenKH.Text,
                    GioiTinh = radNam.Checked ? Constants.BOY : Constants.GIRL,
                    SDT = Convert.ToInt32(txtSĐT.Text),
                    NgaySinh = dtpNgaySinh.Value,
                    Email = txtEmail.Text,
                    CMND = Convert.ToInt32(txtCMND.Text),
                    QuocTich = txtQuocTich.Text
                };
                int result = _khachHangBUS.XoaKhachHang(khachHangDTO);
                if (result > 0)
                {
                    MessageBox.Show(Constants.DELETE_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgvQLKhachHang.DataSource = _khachHangBUS.LayDSKhachHang();
                    txtMaKH.Text = string.Empty;
                    txtSĐT.Text = string.Empty;
                    radNam.Checked = true;
                    txtHoTenKH.Text = string.Empty;
                    dtpNgaySinh.Value = DateTime.Now;
                    txtEmail.Text = string.Empty;
                    txtCMND.Text = string.Empty;
                    txtQuocTich.Text = string.Empty;
                }
                else
                {
                    MessageBox.Show(Constants.DELETE_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            txtMaKH.Text = string.Empty;
            txtSĐT.Text = string.Empty;
            radNam.Checked = true;
            txtHoTenKH.Text = string.Empty;
            dtpNgaySinh.Value = DateTime.Now;
            txtEmail.Text = string.Empty;
            txtCMND.Text = string.Empty;
            txtQuocTich.Text = string.Empty;
            btnTao.Enabled = true;
            btnThem.Enabled = true;
            btnXoa.Enabled = false;
            btnSua.Enabled = false;
        }
       

        private void dgvQLKhachHang_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            btnTao.Enabled = false;
            btnThem.Enabled = false;
            txtMaKH.Enabled = false;
            if (dgvQLKhachHang.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dgvQLKhachHang.CurrentRow.Selected = true;
                txtMaKH.Text = dgvQLKhachHang.Rows[e.RowIndex].Cells["colMaKH"].Value.ToString();
                txtHoTenKH.Text = dgvQLKhachHang.Rows[e.RowIndex].Cells["colHoTenKH"].Value.ToString();
                txtSĐT.Text = dgvQLKhachHang.Rows[e.RowIndex].Cells["colSDT"].Value.ToString();

                if (dgvQLKhachHang.SelectedRows.Count > 0)
                {
                    string gioiTinh = dgvQLKhachHang.Rows[e.RowIndex].Cells["colGioiTinh"].Value.ToString();
                    if (gioiTinh == Constants.BOY)
                    {
                        radNam.Checked = true;
                    }
                    else
                    {
                        radNu.Checked = true;
                    }
                }
                dtpNgaySinh.Text = dgvQLKhachHang.Rows[e.RowIndex].Cells["colNgaySinh"].Value.ToString();
                txtCMND.Text = dgvQLKhachHang.Rows[e.RowIndex].Cells["colCMND"].Value.ToString();
                txtEmail.Text = dgvQLKhachHang.Rows[e.RowIndex].Cells["colEmail"].Value.ToString();
                txtQuocTich.Text = dgvQLKhachHang.Rows[e.RowIndex].Cells["colQuocTich"].Value.ToString();
                btnSua.Enabled = true;
                btnXoa.Enabled = true;

            }
        }

        private void txtSĐT_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSĐT_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtCMND_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCMND_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Bao_Cao bao_cao = new Bao_Cao();
            bao_cao.TatCaKhachHang();
            bao_cao.ShowDialog();
        }
    }
}
