﻿namespace Do_an_quan_ly_khach_san
{
    partial class Hoa_don
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hoa_don));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblGia = new System.Windows.Forms.Label();
            this.lblMaPhong = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblDonGiaLoaiDichVu = new System.Windows.Forms.Label();
            this.lblLoaiDichVu = new System.Windows.Forms.Label();
            this.btnQuayLai = new System.Windows.Forms.Button();
            this.btnDatNgay = new System.Windows.Forms.Button();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.lblTongNgayCuTru = new System.Windows.Forms.Label();
            this.lblNgayLapHoaDon = new System.Windows.Forms.Label();
            this.lblHoTenKH = new System.Windows.Forms.Label();
            this.lblMaKH = new System.Windows.Forms.Label();
            this.lblHoTenNV = new System.Windows.Forms.Label();
            this.lblTenHD = new System.Windows.Forms.Label();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.lblMaHD = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblGia);
            this.groupBox2.Controls.Add(this.lblMaPhong);
            this.groupBox2.Location = new System.Drawing.Point(31, 304);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(268, 58);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Phòng";
            // 
            // lblGia
            // 
            this.lblGia.AutoSize = true;
            this.lblGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGia.ForeColor = System.Drawing.Color.Blue;
            this.lblGia.Location = new System.Drawing.Point(126, 25);
            this.lblGia.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGia.Name = "lblGia";
            this.lblGia.Size = new System.Drawing.Size(45, 15);
            this.lblGia.TabIndex = 1;
            this.lblGia.Text = "lblGia";
            // 
            // lblMaPhong
            // 
            this.lblMaPhong.AutoSize = true;
            this.lblMaPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaPhong.ForeColor = System.Drawing.Color.Blue;
            this.lblMaPhong.Location = new System.Drawing.Point(18, 25);
            this.lblMaPhong.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMaPhong.Name = "lblMaPhong";
            this.lblMaPhong.Size = new System.Drawing.Size(84, 15);
            this.lblMaPhong.TabIndex = 1;
            this.lblMaPhong.Text = "lblMaPhong";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblDonGiaLoaiDichVu);
            this.groupBox1.Controls.Add(this.lblLoaiDichVu);
            this.groupBox1.Location = new System.Drawing.Point(27, 246);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(268, 53);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Loại Dịch Vụ";
            // 
            // lblDonGiaLoaiDichVu
            // 
            this.lblDonGiaLoaiDichVu.AutoSize = true;
            this.lblDonGiaLoaiDichVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDonGiaLoaiDichVu.ForeColor = System.Drawing.Color.Blue;
            this.lblDonGiaLoaiDichVu.Location = new System.Drawing.Point(126, 25);
            this.lblDonGiaLoaiDichVu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDonGiaLoaiDichVu.Name = "lblDonGiaLoaiDichVu";
            this.lblDonGiaLoaiDichVu.Size = new System.Drawing.Size(144, 15);
            this.lblDonGiaLoaiDichVu.TabIndex = 1;
            this.lblDonGiaLoaiDichVu.Text = "lblDonGiaLoaiDichVu";
            // 
            // lblLoaiDichVu
            // 
            this.lblLoaiDichVu.AutoSize = true;
            this.lblLoaiDichVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoaiDichVu.ForeColor = System.Drawing.Color.Blue;
            this.lblLoaiDichVu.Location = new System.Drawing.Point(18, 25);
            this.lblLoaiDichVu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLoaiDichVu.Name = "lblLoaiDichVu";
            this.lblLoaiDichVu.Size = new System.Drawing.Size(96, 15);
            this.lblLoaiDichVu.TabIndex = 1;
            this.lblLoaiDichVu.Text = "lblLoaiDichVu";
            // 
            // btnQuayLai
            // 
            this.btnQuayLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuayLai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnQuayLai.Location = new System.Drawing.Point(241, 453);
            this.btnQuayLai.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnQuayLai.Name = "btnQuayLai";
            this.btnQuayLai.Size = new System.Drawing.Size(88, 34);
            this.btnQuayLai.TabIndex = 27;
            this.btnQuayLai.Text = "Quay Lại";
            this.btnQuayLai.UseVisualStyleBackColor = true;
            // 
            // btnDatNgay
            // 
            this.btnDatNgay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDatNgay.ForeColor = System.Drawing.Color.Red;
            this.btnDatNgay.Location = new System.Drawing.Point(104, 453);
            this.btnDatNgay.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnDatNgay.Name = "btnDatNgay";
            this.btnDatNgay.Size = new System.Drawing.Size(128, 34);
            this.btnDatNgay.TabIndex = 26;
            this.btnDatNgay.Text = "Đặt Ngay";
            this.btnDatNgay.UseVisualStyleBackColor = true;
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongTien.ForeColor = System.Drawing.Color.Blue;
            this.lblTongTien.Location = new System.Drawing.Point(150, 412);
            this.lblTongTien.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(83, 15);
            this.lblTongTien.TabIndex = 24;
            this.lblTongTien.Text = "lblTongTien";
            // 
            // lblTongNgayCuTru
            // 
            this.lblTongNgayCuTru.AutoSize = true;
            this.lblTongNgayCuTru.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongNgayCuTru.ForeColor = System.Drawing.Color.Blue;
            this.lblTongNgayCuTru.Location = new System.Drawing.Point(159, 375);
            this.lblTongNgayCuTru.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTongNgayCuTru.Name = "lblTongNgayCuTru";
            this.lblTongNgayCuTru.Size = new System.Drawing.Size(125, 15);
            this.lblTongNgayCuTru.TabIndex = 23;
            this.lblTongNgayCuTru.Text = "lblTongNgayCuTru";
            // 
            // lblNgayLapHoaDon
            // 
            this.lblNgayLapHoaDon.AutoSize = true;
            this.lblNgayLapHoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgayLapHoaDon.ForeColor = System.Drawing.Color.Blue;
            this.lblNgayLapHoaDon.Location = new System.Drawing.Point(151, 222);
            this.lblNgayLapHoaDon.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNgayLapHoaDon.Name = "lblNgayLapHoaDon";
            this.lblNgayLapHoaDon.Size = new System.Drawing.Size(131, 15);
            this.lblNgayLapHoaDon.TabIndex = 22;
            this.lblNgayLapHoaDon.Text = "lblNgayLapHoaDon";
            // 
            // lblHoTenKH
            // 
            this.lblHoTenKH.AutoSize = true;
            this.lblHoTenKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoTenKH.ForeColor = System.Drawing.Color.Blue;
            this.lblHoTenKH.Location = new System.Drawing.Point(151, 191);
            this.lblHoTenKH.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHoTenKH.Name = "lblHoTenKH";
            this.lblHoTenKH.Size = new System.Drawing.Size(139, 15);
            this.lblHoTenKH.TabIndex = 21;
            this.lblHoTenKH.Text = "lblHoTenKhachHang";
            // 
            // lblMaKH
            // 
            this.lblMaKH.AutoSize = true;
            this.lblMaKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaKH.ForeColor = System.Drawing.Color.Blue;
            this.lblMaKH.Location = new System.Drawing.Point(151, 163);
            this.lblMaKH.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMaKH.Name = "lblMaKH";
            this.lblMaKH.Size = new System.Drawing.Size(117, 15);
            this.lblMaKH.TabIndex = 20;
            this.lblMaKH.Text = "lblMaKhachHang";
            // 
            // lblHoTenNV
            // 
            this.lblHoTenNV.AutoSize = true;
            this.lblHoTenNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoTenNV.ForeColor = System.Drawing.Color.Blue;
            this.lblHoTenNV.Location = new System.Drawing.Point(151, 135);
            this.lblHoTenNV.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHoTenNV.Name = "lblHoTenNV";
            this.lblHoTenNV.Size = new System.Drawing.Size(127, 15);
            this.lblHoTenNV.TabIndex = 19;
            this.lblHoTenNV.Text = "lblHoTenNhanVien";
            // 
            // lblTenHD
            // 
            this.lblTenHD.AutoSize = true;
            this.lblTenHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenHD.ForeColor = System.Drawing.Color.Blue;
            this.lblTenHD.Location = new System.Drawing.Point(148, 84);
            this.lblTenHD.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTenHD.Name = "lblTenHD";
            this.lblTenHD.Size = new System.Drawing.Size(136, 15);
            this.lblTenHD.TabIndex = 25;
            this.lblTenHD.Text = "Hóa Đơn Khách Sạn";
            // 
            // lblMaNV
            // 
            this.lblMaNV.AutoSize = true;
            this.lblMaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaNV.ForeColor = System.Drawing.Color.Blue;
            this.lblMaNV.Location = new System.Drawing.Point(150, 106);
            this.lblMaNV.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMaNV.Name = "lblMaNV";
            this.lblMaNV.Size = new System.Drawing.Size(105, 15);
            this.lblMaNV.TabIndex = 18;
            this.lblMaNV.Text = "lblMaNhanVien";
            // 
            // lblMaHD
            // 
            this.lblMaHD.AutoSize = true;
            this.lblMaHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaHD.ForeColor = System.Drawing.Color.Blue;
            this.lblMaHD.Location = new System.Drawing.Point(151, 58);
            this.lblMaHD.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMaHD.Name = "lblMaHD";
            this.lblMaHD.Size = new System.Drawing.Size(95, 15);
            this.lblMaHD.TabIndex = 16;
            this.lblMaHD.Text = "lblMaHoaDon";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(27, 412);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 17);
            this.label11.TabIndex = 15;
            this.label11.Text = "Tổng Tiền:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(32, 375);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 15);
            this.label4.TabIndex = 14;
            this.label4.Text = "Tổng ngày cư trú:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(24, 222);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 15);
            this.label9.TabIndex = 13;
            this.label9.Text = "Ngày Lập Hóa Đơn:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 191);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 15);
            this.label10.TabIndex = 12;
            this.label10.Text = "Họ Tên Khách Hàng:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 163);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 15);
            this.label7.TabIndex = 11;
            this.label7.Text = "Mã Khách Hàng:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 135);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Họ Tên Nhân Viên:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 106);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Mã Nhân Viên:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 84);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Tên Hóa Đơn:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 58);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 15);
            this.label2.TabIndex = 17;
            this.label2.Text = "Mã Hóa Đơn:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(98, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 26);
            this.label1.TabIndex = 7;
            this.label1.Text = "HÓA ĐƠN";
            // 
            // Hoa_don
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 512);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnQuayLai);
            this.Controls.Add(this.btnDatNgay);
            this.Controls.Add(this.lblTongTien);
            this.Controls.Add(this.lblTongNgayCuTru);
            this.Controls.Add(this.lblNgayLapHoaDon);
            this.Controls.Add(this.lblHoTenKH);
            this.Controls.Add(this.lblMaKH);
            this.Controls.Add(this.lblHoTenNV);
            this.Controls.Add(this.lblTenHD);
            this.Controls.Add(this.lblMaNV);
            this.Controls.Add(this.lblMaHD);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Hoa_don";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hoa_don";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Hoa_don_FormClosing);
            this.Load += new System.EventHandler(this.Hoa_don_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblGia;
        private System.Windows.Forms.Label lblMaPhong;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblDonGiaLoaiDichVu;
        private System.Windows.Forms.Label lblLoaiDichVu;
        private System.Windows.Forms.Button btnQuayLai;
        private System.Windows.Forms.Button btnDatNgay;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.Label lblTongNgayCuTru;
        private System.Windows.Forms.Label lblNgayLapHoaDon;
        private System.Windows.Forms.Label lblHoTenKH;
        private System.Windows.Forms.Label lblMaKH;
        private System.Windows.Forms.Label lblHoTenNV;
        private System.Windows.Forms.Label lblTenHD;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.Label lblMaHD;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}