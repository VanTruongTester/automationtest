﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DTO;
using BUS;

namespace Do_an_quan_ly_khach_san
{
    public partial class Dich_vu : Form
    {
        private DichVuBUS _dichVuBUS = new DichVuBUS();
        private DichVuDTO _dichVuDTO = new DichVuDTO();
        public Dich_vu()
        {
            InitializeComponent();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaDichVu.Text) && string.IsNullOrEmpty(txtLoaiDichVu.Text))
            {
                MessageBox.Show(Constants.CHOOSE_DELETE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK);
            }
            else
            {
                DialogResult dlr = MessageBox.Show(Constants.SURE_DELETE_SERVICE, Constants.MESSAGE_TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (dlr == DialogResult.Yes)
                {
                    DichVuDTO dichVuDTO = new DichVuDTO
                    {
                        MaDichVu = Convert.ToInt32(txtMaDichVu.Text),
                        LoaiDichVu = txtLoaiDichVu.Text,
                        DonGia = Convert.ToInt32(nudDonGia.Value)
                    };

                    int result = _dichVuBUS.XoaDichVu(dichVuDTO);

                    if (result > 0)
                    {
                        MessageBox.Show(Constants.DELETE_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvDichVu.DataSource = _dichVuBUS.LayDSDichVu();
                        txtMaDichVu.Text = string.Empty;
                        txtLoaiDichVu.Text = string.Empty;
                        nudDonGia.Value = 0;
                    }
                    else
                    {
                        MessageBox.Show(Constants.DELETE_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
            }
        }

        private void btnQuayLai_Click(object sender, EventArgs e)
        {
            Trang_chu f = new Trang_chu(true);
            this.Hide();
            f.ShowDialog();
        }

        private void Dich_vu_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void btnTao_Click(object sender, EventArgs e)
        {
            txtMaDichVu.Text = (_dichVuBUS.MaxMaDichVu() + 1).ToString();
            txtLoaiDichVu.Text = string.Empty;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaDichVu.Text) || string.IsNullOrEmpty(txtLoaiDichVu.Text))
            {
                MessageBox.Show(Constants.ERR_REQUIRED, Constants.MESSAGE_TITLE, MessageBoxButtons.OK);
                txtLoaiDichVu.Text = string.Empty;
            }
            else if (string.IsNullOrWhiteSpace(txtLoaiDichVu.Text))
            {
                MessageBox.Show(Constants.NO_SPACE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtLoaiDichVu.Text = string.Empty;
            }
            else if (nudDonGia.Value <= Constants.DON_GIA_MIN || nudDonGia.Value > Constants.DON_GIA_MAX)
            {
                MessageBox.Show(Constants.PRICE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                if (_dichVuBUS.KiemTraTrungLap(Convert.ToInt32(txtMaDichVu.Text)))
                {
                    MessageBox.Show(Constants.EXIST_PASS_SERVICE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (_dichVuBUS.KiemTraTrungLapTen(Convert.ToString(txtLoaiDichVu.Text)))
                {
                    MessageBox.Show(Constants.EXIST_PASS_SERVICE_NAME, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    DichVuDTO dichVuDTO = new DichVuDTO()
                    {
                        MaDichVu = Convert.ToInt32(txtMaDichVu.Text),
                        LoaiDichVu = txtLoaiDichVu.Text,
                        DonGia = Convert.ToInt32(nudDonGia.Value)
                    };
                    int result = _dichVuBUS.ThemDichVu(dichVuDTO);
                    if (result > 0)
                    {
                        MessageBox.Show(Constants.ADD_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvDichVu.DataSource = _dichVuBUS.LayDSDichVu();
                        txtMaDichVu.Text = string.Empty;
                        txtLoaiDichVu.Text = string.Empty;
                        nudDonGia.Value = 0;
                    }
                    else
                    {
                        MessageBox.Show(Constants.ADD_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            txtMaDichVu.Enabled = false;
            if (string.IsNullOrEmpty(txtLoaiDichVu.Text))
            {
                MessageBox.Show(Constants.ERR_REQUIRED, Constants.MESSAGE_TITLE, MessageBoxButtons.OK);
            }
            else if (string.IsNullOrWhiteSpace(txtLoaiDichVu.Text))
            {
                MessageBox.Show(Constants.NO_SPACE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtLoaiDichVu.Text = string.Empty;
            }
            else
            {
                DichVuDTO dichVuDTO = new DichVuDTO
                {
                    MaDichVu = Convert.ToInt32(txtMaDichVu.Text),
                    LoaiDichVu = txtLoaiDichVu.Text,
                    DonGia = Convert.ToInt32(nudDonGia.Value)
                };

                int result = _dichVuBUS.CapNhatDichVu(dichVuDTO);
                if (result > 0)
                {
                    MessageBox.Show(Constants.UPADATE_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgvDichVu.DataSource = _dichVuBUS.LayDSDichVu();
                    txtMaDichVu.Text = string.Empty;
                    txtLoaiDichVu.Text = string.Empty;
                    nudDonGia.Value = 0;
                }
                else
                {
                    MessageBox.Show(Constants.UPADATE_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            btnTao.Enabled = true;
            btnThem.Enabled = true;
            btnXoa.Enabled = false;
            btnSua.Enabled = false;
            txtMaDichVu.Text = string.Empty;
            txtLoaiDichVu.Text = string.Empty;
            nudDonGia.Value = 0;
        }

        private void dgvDichVu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            btnSua.Enabled = true;
            btnXoa.Enabled = true;
            btnThem.Enabled = false;
            btnTao.Enabled = false;
            txtMaDichVu.Enabled = false;
            if (e.RowIndex < 0) return;

            txtMaDichVu.Text = dgvDichVu.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtLoaiDichVu.Text = dgvDichVu.Rows[e.RowIndex].Cells[1].Value.ToString();
            nudDonGia.Value = Convert.ToInt32(dgvDichVu.Rows[e.RowIndex].Cells[2].Value);
        }

        private void Dich_vu_Load(object sender, EventArgs e)
        {
            dgvDichVu.DataSource = _dichVuBUS.LayDSDichVu();
            txtMaDichVu.Enabled = false;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
        }
    }
}
