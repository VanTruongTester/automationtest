﻿using BUS;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_an_quan_ly_khach_san
{
    public partial class Dang_nhap : Form
    {
        private DangNhapBUS _danhNhapBUS = new DangNhapBUS();
        private NhanVienDTO _nhanVienDTO = new NhanVienDTO();
        private NhanVienDTO nhanVienDTO = new NhanVienDTO();

        public static bool checkPhanQuyen = false;
        public Dang_nhap()
        {
            InitializeComponent();
            chkHienThiMK.BackColor = Color.Transparent;

            txtTenDangNhap.Text = string.Empty;
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTenDangNhap.Text) || string.IsNullOrEmpty(txtMatKhau.Text))
            {
                MessageBox.Show(Constants.ERR_ACC_PASS_REQUIRED, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (txtTenDangNhap.Text == "admin" && txtMatKhau.Text == "1234")
                {
                    MessageBox.Show(Constants.LOGIN_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    NhanVienHienHanhDTO.NhanVienHHDTO = nhanVienDTO;
                    checkPhanQuyen = true;
                    Trang_chu fTrangChu = new Trang_chu(checkPhanQuyen);
                    fTrangChu.Show();
                    this.Hide();
                }
                else
                {
                    if (_danhNhapBUS.KiemTraDinhDangEmail(txtTenDangNhap.Text))
                    {

                        nhanVienDTO = _danhNhapBUS.DangNhapNhanVien(txtTenDangNhap.Text, txtMatKhau.Text);
                        if (nhanVienDTO != null)
                        {
                            MessageBox.Show(Constants.LOGIN_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            NhanVienHienHanhDTO.NhanVienHHDTO = nhanVienDTO;
                            checkPhanQuyen = false;
                            Trang_chu fTrangChu = new Trang_chu(checkPhanQuyen);
                            fTrangChu.Show();
                            this.Hide();
                        }

                        else
                        {
                            MessageBox.Show(Constants.LOGIN_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show(Constants.ERR_ACCOUNT_FORMAT, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
         

        }

        private void Dang_nhap_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void Dang_nhap_Load(object sender, EventArgs e)
        {

        }

        private void chkHienThiMK_CheckedChanged(object sender, EventArgs e)
        {
            if (chkHienThiMK.Checked == false)
            {
                txtMatKhau.UseSystemPasswordChar = false;
            }
            else
            {
                txtMatKhau.UseSystemPasswordChar = true;
            }
        }

        private void txtTenDangNhap_Enter(object sender, EventArgs e)
        {
            if (txtTenDangNhap.Text == Constants.LOGIN_NAME)
            {
                txtTenDangNhap.Text = "";
                txtTenDangNhap.ForeColor = Color.Black;
            }
        }

        private void txtTenDangNhap_Leave(object sender, EventArgs e)
        {
            if (txtTenDangNhap.Text == "")
            {
                txtTenDangNhap.Text = Constants.LOGIN_NAME;
                txtTenDangNhap.ForeColor = Color.Gray;
            }
        }

        private void txtMatKhau_Enter(object sender, EventArgs e)
        {
            if (txtMatKhau.Text == Constants.PASSWORD)
            {
                txtMatKhau.Text = "";
                txtMatKhau.ForeColor = Color.Black;
            }
        }

        private void txtMatKhau_Leave(object sender, EventArgs e)
        {
            if (txtMatKhau.Text == "")
            {
                txtMatKhau.Text = Constants.PASSWORD;
                txtMatKhau.ForeColor = Color.Gray;
            }
        }

    }
}
