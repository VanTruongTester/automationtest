﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using DTO;
using BUS;

namespace Do_an_quan_ly_khach_san
{
    public partial class Bao_Cao : Form
    {
        private NhanVienBUS _nvBUS = new NhanVienBUS();
        private PhongBUS _phongBUS = new PhongBUS();
        private KhachHangBUS _khBUS = new KhachHangBUS();
        private QLHoaDonBUS _qlHoaDonBUS = new QLHoaDonBUS();
        public Bao_Cao()
        {
            InitializeComponent();
        }

        private void Bao_Cao_HD_Load(object sender, EventArgs e)
        {

            this.rpwBaoCao.RefreshReport();
        }
        public void TatCaHoDon()
        {
            try
            {
                List<QLHoaDonDTO> _qlHoaDonDTO = new List<QLHoaDonDTO>();
                _qlHoaDonDTO = _qlHoaDonBUS.LayDSHoaDon();

                this.rpwBaoCao.LocalReport.ReportEmbeddedResource = "Do_an_quan_ly_khach_san.rptDSTCHoaDon.rdlc";

                this.rpwBaoCao.LocalReport.DataSources.Add(new ReportDataSource("HoaDon", _qlHoaDonDTO));

                this.rpwBaoCao.RefreshReport();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void TatCaNhanVien()
        {
            try
            {
                List<NhanVienDTO> _qlNhanVienDTO = new List<NhanVienDTO>();
                _qlNhanVienDTO = _nvBUS.LayDSNhanVien();

                this.rpwBaoCao.LocalReport.ReportEmbeddedResource = "Do_an_quan_ly_khach_san.rptDSNhanVien.rdlc";

                this.rpwBaoCao.LocalReport.DataSources.Add(new ReportDataSource("NhanVien", _qlNhanVienDTO));

                this.rpwBaoCao.RefreshReport();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void TatCaKhachHang()
        {
            try
            {
                List<KhachHangDTO> _khDTO = new List<KhachHangDTO>();
                _khDTO = _khBUS.LayDSKhachHang();

                rpwBaoCao.LocalReport.ReportEmbeddedResource = "Do_an_quan_ly_khach_san.rptDSKhachHang.rdlc";

                rpwBaoCao.LocalReport.DataSources.Add(new ReportDataSource("KhachHang", _khDTO));

                this.rpwBaoCao.RefreshReport();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
