﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
using DTO;

namespace Do_an_quan_ly_khach_san
{
    public partial class Ql_Hoa_don : Form
    {
        private QLHoaDonBUS _qlHoaDonBUS = new QLHoaDonBUS();
        private QLHoaDonDTO _qlHoaDonDTO = new QLHoaDonDTO();
        private NhanVienBUS _nhanVienBUS = new NhanVienBUS();
        private KhachHangBUS _khachHangBUS = new KhachHangBUS();
        public Ql_Hoa_don()
        {
            InitializeComponent();
        }

        private void btnquaylai_Click(object sender, EventArgs e)
        {
            Trang_chu f = new Trang_chu(true);
            this.Hide();
            f.ShowDialog();
        }

        private void Ql_Hoa_don_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void dgvQLHoaDon_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            txtMaHD.Text = dgvQLHoaDon.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtTenHD.Text = dgvQLHoaDon.Rows[e.RowIndex].Cells[1].Value.ToString();
            cboMaNV.Text = dgvQLHoaDon.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtHoTenNV.Text = dgvQLHoaDon.Rows[e.RowIndex].Cells[3].Value.ToString();
            cboMaKH.Text = dgvQLHoaDon.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtHoTenKH.Text = dgvQLHoaDon.Rows[e.RowIndex].Cells[5].Value.ToString();
            dtpNgayLapHD.Value = Convert.ToDateTime(dgvQLHoaDon.Rows[e.RowIndex].Cells[6].Value.ToString());
            txtTongTien.Text = dgvQLHoaDon.Rows[e.RowIndex].Cells[7].Value.ToString();
            txtMaPhong.Text = dgvQLHoaDon.Rows[e.RowIndex].Cells[8].Value.ToString();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaHD.Text) || string.IsNullOrEmpty(txtTenHD.Text) || string.IsNullOrEmpty(txtHoTenKH.Text)
               || string.IsNullOrEmpty(txtTongTien.Text))
            {
                MessageBox.Show(Constants.ERR_REQUIRED, Constants.MESSAGE_TITLE, MessageBoxButtons.OK);
            }
            else
            {
                DialogResult dlr = MessageBox.Show(Constants.SURE_DELETE_BILL, Constants.MESSAGE_TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (dlr == DialogResult.Yes)
                {
                    QLHoaDonDTO hoaDonDTO = new QLHoaDonDTO
                    {
                        MaHD = Convert.ToInt32(txtMaHD.Text),
                        TenHD = txtTenHD.Text,
                        MaNV = Convert.ToInt32(cboMaNV.Text),
                        HoTenNV = txtHoTenNV.Text,
                        MaKH = cboMaKH.Text,
                        HoTenKH = txtHoTenKH.Text,
                        NgayLapHD = dtpNgayLapHD.Value,
                        TongTien = Convert.ToInt32(txtTongTien.Text)
                    };
                    int result = _qlHoaDonBUS.XoaHoaDon(hoaDonDTO);
                    if (result > 0)
                    {
                        MessageBox.Show(Constants.DELETE_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvQLHoaDon.DataSource = _qlHoaDonBUS.LayDSHoaDon();
                        txtMaHD.Text = string.Empty;
                        txtTenHD.Text = string.Empty;
                        cboMaNV.Text = string.Empty;
                        txtHoTenNV.Text = string.Empty;
                        cboMaKH.Text = string.Empty;
                        txtHoTenKH.Text = string.Empty;
                        dtpNgayLapHD.Value = DateTime.Now;
                        txtTongTien.Text = string.Empty;
                        txtMaPhong.Text = string.Empty;
                    }
                    else
                    {
                        MessageBox.Show(Constants.DELETE_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {

            txtMaHD.Enabled = false;
            txtTenHD.Enabled = false;
            cboMaNV.Enabled = false;
            txtHoTenNV.Enabled = false;
            cboMaKH.Enabled = false;
            txtHoTenKH.Enabled = false;
            txtMaPhong.Enabled = false;
            txtTongTien.Enabled = false;
            dtpNgayLapHD.Enabled = false;
            txtMaHD.Text = string.Empty;
            txtTenHD.Text = string.Empty;
            cboMaNV.Text = string.Empty;
            txtHoTenNV.Text = string.Empty;
            cboMaKH.Text = string.Empty;
            txtHoTenKH.Text = string.Empty;
            dtpNgayLapHD.Value = DateTime.Now;
            txtTongTien.Text = string.Empty;
            txtMaPhong.Text = string.Empty;
        }

        private void Ql_Hoa_don_Load(object sender, EventArgs e)
        {
            dgvQLHoaDon.DataSource = _qlHoaDonBUS.LayDSHoaDon();
            cboMaNV.DataSource = _nhanVienBUS.LayDSNhanVien();
            cboMaNV.DisplayMember = "MaNV";
            cboMaNV.ValueMember = "MaNV";
            cboMaKH.DataSource = _khachHangBUS.LayDSKhachHang();
            cboMaKH.DisplayMember = "MaKH";
            cboMaKH.ValueMember = "MaKH";
            txtMaHD.Enabled = false;
            txtTenHD.Enabled = false;
            cboMaNV.Enabled = false;
            txtHoTenNV.Enabled = false;
            cboMaKH.Enabled = false;
            txtHoTenKH.Enabled = false;
            txtMaPhong.Enabled = false;
            txtTongTien.Enabled = false;
            dtpNgayLapHD.Enabled = false;
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Bao_Cao bao_cao_hd = new Bao_Cao();
            bao_cao_hd.TatCaHoDon();
            bao_cao_hd.ShowDialog();
        }
    }
}
