﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Do_an_quan_ly_khach_san
{
    public partial class Xem_bao_cao : Form
    {
        public Xem_bao_cao()
        {
            InitializeComponent();
        }
    }
}
