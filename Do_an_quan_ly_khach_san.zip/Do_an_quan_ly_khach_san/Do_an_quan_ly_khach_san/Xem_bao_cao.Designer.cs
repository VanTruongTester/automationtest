﻿namespace Do_an_quan_ly_khach_san
{
    partial class Xem_bao_cao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboHoaDonTheoNgay = new System.Windows.Forms.ComboBox();
            this.cboKHTheoNgay = new System.Windows.Forms.ComboBox();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnXemBaoCao = new System.Windows.Forms.Button();
            this.rbnTatCaHoaDon = new System.Windows.Forms.RadioButton();
            this.rbnHoaDonTheoNgayLap = new System.Windows.Forms.RadioButton();
            this.rbnTatCaKhachHangTheoNgay = new System.Windows.Forms.RadioButton();
            this.rbnTatCaKhachHang = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cboHoaDonTheoNgay
            // 
            this.cboHoaDonTheoNgay.FormattingEnabled = true;
            this.cboHoaDonTheoNgay.Location = new System.Drawing.Point(171, 522);
            this.cboHoaDonTheoNgay.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.cboHoaDonTheoNgay.Name = "cboHoaDonTheoNgay";
            this.cboHoaDonTheoNgay.Size = new System.Drawing.Size(348, 33);
            this.cboHoaDonTheoNgay.TabIndex = 21;
            // 
            // cboKHTheoNgay
            // 
            this.cboKHTheoNgay.FormattingEnabled = true;
            this.cboKHTheoNgay.Location = new System.Drawing.Point(168, 326);
            this.cboKHTheoNgay.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.cboKHTheoNgay.Name = "cboKHTheoNgay";
            this.cboKHTheoNgay.Size = new System.Drawing.Size(348, 33);
            this.cboKHTheoNgay.TabIndex = 22;
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnThoat.Location = new System.Drawing.Point(456, 628);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(235, 68);
            this.btnThoat.TabIndex = 19;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            // 
            // btnXemBaoCao
            // 
            this.btnXemBaoCao.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemBaoCao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnXemBaoCao.Location = new System.Drawing.Point(160, 628);
            this.btnXemBaoCao.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnXemBaoCao.Name = "btnXemBaoCao";
            this.btnXemBaoCao.Size = new System.Drawing.Size(235, 68);
            this.btnXemBaoCao.TabIndex = 20;
            this.btnXemBaoCao.Text = "Xem Báo Cáo";
            this.btnXemBaoCao.UseVisualStyleBackColor = true;
            // 
            // rbnTatCaHoaDon
            // 
            this.rbnTatCaHoaDon.AutoSize = true;
            this.rbnTatCaHoaDon.BackColor = System.Drawing.Color.Transparent;
            this.rbnTatCaHoaDon.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTatCaHoaDon.Location = new System.Drawing.Point(166, 405);
            this.rbnTatCaHoaDon.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.rbnTatCaHoaDon.Name = "rbnTatCaHoaDon";
            this.rbnTatCaHoaDon.Size = new System.Drawing.Size(245, 40);
            this.rbnTatCaHoaDon.TabIndex = 15;
            this.rbnTatCaHoaDon.TabStop = true;
            this.rbnTatCaHoaDon.Text = "Tất cả hóa đơn";
            this.rbnTatCaHoaDon.UseVisualStyleBackColor = false;
            // 
            // rbnHoaDonTheoNgayLap
            // 
            this.rbnHoaDonTheoNgayLap.AutoSize = true;
            this.rbnHoaDonTheoNgayLap.BackColor = System.Drawing.Color.Transparent;
            this.rbnHoaDonTheoNgayLap.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnHoaDonTheoNgayLap.Location = new System.Drawing.Point(166, 467);
            this.rbnHoaDonTheoNgayLap.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.rbnHoaDonTheoNgayLap.Name = "rbnHoaDonTheoNgayLap";
            this.rbnHoaDonTheoNgayLap.Size = new System.Drawing.Size(346, 40);
            this.rbnHoaDonTheoNgayLap.TabIndex = 16;
            this.rbnHoaDonTheoNgayLap.TabStop = true;
            this.rbnHoaDonTheoNgayLap.Text = "Hóa đơn theo ngày lập";
            this.rbnHoaDonTheoNgayLap.UseVisualStyleBackColor = false;
            // 
            // rbnTatCaKhachHangTheoNgay
            // 
            this.rbnTatCaKhachHangTheoNgay.AutoSize = true;
            this.rbnTatCaKhachHangTheoNgay.BackColor = System.Drawing.Color.Transparent;
            this.rbnTatCaKhachHangTheoNgay.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTatCaKhachHangTheoNgay.Location = new System.Drawing.Point(166, 276);
            this.rbnTatCaKhachHangTheoNgay.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.rbnTatCaKhachHangTheoNgay.Name = "rbnTatCaKhachHangTheoNgay";
            this.rbnTatCaKhachHangTheoNgay.Size = new System.Drawing.Size(486, 40);
            this.rbnTatCaKhachHangTheoNgay.TabIndex = 17;
            this.rbnTatCaKhachHangTheoNgay.TabStop = true;
            this.rbnTatCaKhachHangTheoNgay.Text = "Tổng hợp khách hàng theo ngày:";
            this.rbnTatCaKhachHangTheoNgay.UseVisualStyleBackColor = false;
            // 
            // rbnTatCaKhachHang
            // 
            this.rbnTatCaKhachHang.AutoSize = true;
            this.rbnTatCaKhachHang.BackColor = System.Drawing.Color.Transparent;
            this.rbnTatCaKhachHang.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbnTatCaKhachHang.Location = new System.Drawing.Point(166, 204);
            this.rbnTatCaKhachHang.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.rbnTatCaKhachHang.Name = "rbnTatCaKhachHang";
            this.rbnTatCaKhachHang.Size = new System.Drawing.Size(294, 40);
            this.rbnTatCaKhachHang.TabIndex = 18;
            this.rbnTatCaKhachHang.TabStop = true;
            this.rbnTatCaKhachHang.Text = "Tất cả khách hàng";
            this.rbnTatCaKhachHang.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(251, 97);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(328, 57);
            this.label1.TabIndex = 14;
            this.label1.Text = "Bảng Báo Cáo";
            // 
            // Xem_bao_cao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 793);
            this.Controls.Add(this.cboHoaDonTheoNgay);
            this.Controls.Add(this.cboKHTheoNgay);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnXemBaoCao);
            this.Controls.Add(this.rbnTatCaHoaDon);
            this.Controls.Add(this.rbnHoaDonTheoNgayLap);
            this.Controls.Add(this.rbnTatCaKhachHangTheoNgay);
            this.Controls.Add(this.rbnTatCaKhachHang);
            this.Controls.Add(this.label1);
            this.Name = "Xem_bao_cao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Xem_bao_cao";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboHoaDonTheoNgay;
        private System.Windows.Forms.ComboBox cboKHTheoNgay;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnXemBaoCao;
        private System.Windows.Forms.RadioButton rbnTatCaHoaDon;
        private System.Windows.Forms.RadioButton rbnHoaDonTheoNgayLap;
        private System.Windows.Forms.RadioButton rbnTatCaKhachHangTheoNgay;
        private System.Windows.Forms.RadioButton rbnTatCaKhachHang;
        private System.Windows.Forms.Label label1;
    }
}