﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
using DTO;

namespace Do_an_quan_ly_khach_san
{
    public partial class Dang_ky : Form
    {
        private LoaiPhongBUS loaiPhongBUS = new LoaiPhongBUS();
        private PhongBUS phongBUS = new PhongBUS();
        private PhongDTO phongDTO = new PhongDTO();
        private DichVuBUS dichVuBUS = new DichVuBUS();
        private DangKyBUS dangKyBus = new DangKyBUS();
        private KhachHangBUS khachHangBUS = new KhachHangBUS();
        public static int SoDK;
        public static int MaNV;
        public static string MaKH;
        public static int MaDichVu;
        public static int MaPhong;
        private static int soNgay;
        public Dang_ky()
        {
            InitializeComponent();
            cboMaKH.DataSource = khachHangBUS.LayDSKhachHang();
            cboLoaiDichVu.DataSource = dichVuBUS.LayDSDichVu();
            cboLoaiDichVu.DisplayMember = "LoaiDichVu"; ;
            cboLoaiDichVu.ValueMember = "MaDichVu";
            cboMaKH.DisplayMember = "MaKH";
            cboMaKH.ValueMember = "MaKH";
        }

        private void btnQL_Click(object sender, EventArgs e)
        {
            Trang_chu f = new Trang_chu(true);
            this.Hide();
            f.ShowDialog();
        }

        private void Dang_ky_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void dgvChonPhong_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (String.Compare(dgvChonPhong.Rows[e.RowIndex].Cells[3].Value.ToString(), "Đang sử dụng", true) == 0)
            {
                MessageBox.Show("Phòng đang được sử dụng", Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMaPhong.Text = string.Empty;
            }
            else
            {
                txtMaPhong.Text = dgvChonPhong.Rows[e.RowIndex].Cells[0].Value.ToString();
            }
        }

        private void btnTao_Click(object sender, EventArgs e)
        {
            txtSoDK.Text = (dangKyBus.MaxSoDK() + 1).ToString();
        }

        private void btnTaoKH_Click(object sender, EventArgs e)
        {
            Ql_Khach_hang qlKhachHang = new Ql_Khach_hang();
            qlKhachHang.ShowDialog();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
           
            if (string.IsNullOrEmpty(txtSoDK.Text) || string.IsNullOrEmpty(txtMaPhong.Text))
            {
                MessageBox.Show(Constants.ERR_REQUIRED, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (dtpNgayNhan.Text == DateTime.Now.ToString(Constants.DATETIME) || dtpNgayNhan.Value > Convert.ToDateTime(DateTime.Now.ToString(Constants.DATETIME)))
                {
                    if (dtpNgayNhan.Value > Convert.ToDateTime(DateTime.Now.ToString(Constants.DATETIME)))
                    {
                        if (dtpNgayTra.Value > Convert.ToDateTime(dtpNgayNhan.Value.ToString(Constants.DATETIME)) && dtpNgayTra.Value != Convert.ToDateTime(dtpNgayNhan.Value.ToString(Constants.DATETIME)))
                        {
                            DangKyDTO dangKyDTO = new DangKyDTO()
                            {
                                SoDK = Convert.ToInt32(txtSoDK.Text),
                                NgayDK = dtpNgayDK.Value,
                                MaPhong = Convert.ToInt32(txtMaPhong.Text),
                                MaKH = cboMaKH.Text,
                                NgayGioDen = dtpNgayNhan.Value,
                                NgayGioDi = dtpNgayTra.Value
                            };
                            int result = dangKyBus.DangKy(dangKyDTO);
                            if (result > 0)
                            {
                                MessageBox.Show(Constants.REGI, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                SoDK = Convert.ToInt32(txtSoDK.Text);
                                MaKH = cboMaKH.Text;
                                MaDichVu = Convert.ToInt32(cboLoaiDichVu.SelectedValue.ToString());
                                MaPhong = Convert.ToInt32(txtMaPhong.Text);
                                soNgay = TinhNgay();

                                int sua = dangKyBus.Sua(dangKyDTO);
                                if (sua > 0)
                                {
                                    Hoa_don fHoaDon = new Hoa_don();
                                    this.Close();
                                    fHoaDon.Show();
                                    dgvChonPhong.DataSource = phongBUS.LayDSPhong();
                                }
                                else
                                {
                                    MessageBox.Show(Constants.UPADATE_ROOM_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show(Constants.DAY_PAY_NOT_EQUAL_DAY_REGI, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show(Constants.DAY_RECE_NOT_EQUAL_DAY_NOW, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(Constants.DAY_RECE_NOT_EQUAL_DAY_NOW, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Dang_ky_Load(object sender, EventArgs e)
        {
            dtpNgayDK.Enabled = false;
            colMaLoaiPhong.DataSource = loaiPhongBUS.LayDSLoaiPhong();
            colMaLoaiPhong.DisplayMember = "TenLoaiPhong";
            colMaLoaiPhong.ValueMember = "MaLoaiPhong";
            dgvChonPhong.DataSource = phongBUS.LayDSPhong();
            txtSoDK.Enabled = false;
            txtMaPhong.Enabled = false;
        }
        public int LaySoDK()
        {
            return SoDK;
        }
        public int LayMaNV()
        {
            return MaNV;
        }
        public string LayMaKH()
        {
            return MaKH;
        }
        public int LayMaDichVu()
        {
            return MaDichVu;
        }
        public int LayMaPhong()
        {
            return MaPhong;
        }
        public int TinhNgay()
        {
            TimeSpan soNgay = dtpNgayTra.Value - dtpNgayNhan.Value;
            return Convert.ToInt32(soNgay.TotalDays);
        }
        public int LayTongNgay()
        {
            return soNgay;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void cboMaKH_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnMP_Click(object sender, EventArgs e)
        {
            txtSoDK.Text = (dangKyBus.MaxMP() + 1).ToString();
        }
    }
}
