﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
using DTO;
namespace Do_an_quan_ly_khach_san
{
    public partial class Ql_Phong : Form
    {

        private PhongDTO _phongDTO = new PhongDTO();
        private PhongBUS _phongBUS = new PhongBUS();
       private LoaiPhongBUS _loaiPhongBUS = new LoaiPhongBUS();
        public Ql_Phong()
        {
            InitializeComponent();
            cboMaLoaiPhong.DataSource = _loaiPhongBUS.LayDSLoaiPhong();
            cboMaLoaiPhong.DisplayMember = "TenLoaiPhong";
            cboMaLoaiPhong.ValueMember = "MaLoaiPhong";
            cboMaLoaiPhong.SelectedIndex = 0;
            cboTinhTrang.Items.Add("Trống");
            cboTinhTrang.Items.Add("Đang sử dụng");
            cboTinhTrang.SelectedItem = "Trống";
            dgvPhong.AutoGenerateColumns = false;
          
        }

        private void btnQuayLai_Click(object sender, EventArgs e)
        {
            Trang_chu f = new Trang_chu(true);
            this.Hide();
            f.ShowDialog();
        }

        private void Ql_Phong_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void btnTao_Click(object sender, EventArgs e)
        {
            txtMaPhong.Text = (_phongBUS.MaxMaPhong() + 1).ToString();
        }

        private void Ql_Phong_Load(object sender, EventArgs e)
        {
            dgvPhong.DataSource = _phongBUS.LayDSPhong();
            colMaLoaiPhong.DataSource = _loaiPhongBUS.LayDSLoaiPhong();
            colMaLoaiPhong.DisplayMember = "TenLoaiPhong";
            colMaLoaiPhong.ValueMember = "MaLoaiPhong";
            colMaLoaiPhong.DataPropertyName = "MaLoaiPhong";
            txtMaPhong.Enabled = false;
            btnCapNhat.Enabled = false;
            btnXoa.Enabled = false;
            btnThem.BackColor = Color.White;
            btnLamMoi.BackColor = Color.White;
            btnQuayLai.BackColor = Color.White;
        }

        private void dgvPhong_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            btnTao.Enabled = false;
            btnThem.Enabled = false;
            btnThem.BackColor = Color.Transparent;
            txtMaPhong.Enabled = false;

            if (e.RowIndex < 0) return;
            txtMaPhong.Text = dgvPhong.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtGiaPhong.Text = dgvPhong.Rows[e.RowIndex].Cells[1].Value.ToString();
            cboMaLoaiPhong.SelectedValue = dgvPhong.SelectedCells[2].Value.ToString();
            cboTinhTrang.SelectedItem = dgvPhong.SelectedCells[3].Value.ToString();
            btnCapNhat.Enabled = true;
            btnXoa.Enabled = true;
            btnCapNhat.BackColor = Color.White;
            btnXoa.BackColor = Color.White;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            btnTao.Enabled = true;
            if (string.IsNullOrEmpty(txtMaPhong.Text) || string.IsNullOrEmpty(txtGiaPhong.Text))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK);
            }
            else if (string.IsNullOrWhiteSpace(txtGiaPhong.Text))
            {
                MessageBox.Show("Không được sử dụng khoảng trắng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtGiaPhong.Text = string.Empty;
            }
            else if (Convert.ToInt32(txtGiaPhong.Text) > 10000000 || Convert.ToInt32(txtGiaPhong.Text) <= 0)
            {
                MessageBox.Show("Đơn giá không được nhỏ hơn, bằng 0 hoặc lớn hơn 10000000", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtGiaPhong.Text = string.Empty;
                return;
            }
            else
            {
                if (_phongBUS.KiemTraTrungLap(Convert.ToInt32(txtMaPhong.Text)))
                {
                    MessageBox.Show("Mã phòng đã tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (cboTinhTrang.SelectedItem == "Đang sử dụng")
                {
                    MessageBox.Show("Tình trạng phòng phải trống", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cboTinhTrang.SelectedItem = "Trống";
                    return;
                }
                else
                {
                    PhongDTO phongDTO = new PhongDTO
                    {
                        MaPhong = Convert.ToInt32(txtMaPhong.Text),
                        Gia = Convert.ToInt32(txtGiaPhong.Text),
                        MaLoaiPhong = cboMaLoaiPhong.SelectedValue.ToString(),
                    };
                    int result = _phongBUS.ThemPhong(phongDTO);
                    if (result > 0)
                    {
                        MessageBox.Show("Thêm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvPhong.DataSource = _phongBUS.LayDSPhong();
                        txtMaPhong.Text = string.Empty;
                        txtMaPhong.Text = string.Empty;
                        txtGiaPhong.Text = string.Empty;
                        cboMaLoaiPhong.SelectedValue = 0;
                        cboTinhTrang.SelectedIndex = 0;
                    }
                    else
                    {
                        MessageBox.Show("Thêm thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            btnTao.Enabled = true;
            btnThem.Enabled = true;
            btnThem.BackColor = Color.White;
            txtMaPhong.Text = string.Empty;
            txtGiaPhong.Text = string.Empty;
            cboMaLoaiPhong.SelectedIndex = 0;
            cboTinhTrang.SelectedIndex = 0;
            btnCapNhat.Enabled = false;
            btnXoa.Enabled = false;
            btnCapNhat.BackColor = Color.Transparent;
            btnXoa.BackColor = Color.Transparent;
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaPhong.Text) || string.IsNullOrEmpty(txtGiaPhong.Text))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK);
            }
            else if (Convert.ToInt32(txtGiaPhong.Text) > 10000000 || Convert.ToInt32(txtGiaPhong.Text) <=0)
            {
                MessageBox.Show("Đơn giá không được nhỏ hơn, bằng 0 hoặc lớn hơn 10000000", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtGiaPhong.Text = string.Empty;
                return;
            }
            else
            {
                PhongDTO phongDTO = new PhongDTO
                {
                    MaPhong = Convert.ToInt32(txtMaPhong.Text),
                    Gia = Convert.ToInt32(txtGiaPhong.Text),
                    MaLoaiPhong = cboMaLoaiPhong.SelectedValue.ToString(),
                    TinhTrang = cboTinhTrang.SelectedItem.ToString()
                };
                int result = _phongBUS.CapNhatPhong(phongDTO);
                if (result > 0)
                {
                    MessageBox.Show("Cập nhật thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgvPhong.DataSource = _phongBUS.LayDSPhong();
                    txtMaPhong.Enabled = true;
                    txtMaPhong.Text = string.Empty;
                    txtGiaPhong.Text = string.Empty;
                    cboMaLoaiPhong.SelectedIndex = 0;
                    cboTinhTrang.SelectedIndex = 0;
                }
                else
                {
                    MessageBox.Show("Cập nhật thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaPhong.Text) || string.IsNullOrEmpty(txtGiaPhong.Text))
            {
                MessageBox.Show("Vui lòng chọn thông tin cần xóa", "Thông báo", MessageBoxButtons.OK);
            }
            else
            {
                if (String.Compare(dgvPhong.SelectedRows[0].Cells[3].Value.ToString(), "Đang sử dụng", true) == 0)
                {
                    MessageBox.Show("Phòng đang được sử dụng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                DialogResult dlr = MessageBox.Show("Bạn có chắc chắn muốn xóa phòng này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (dlr == DialogResult.Yes)
                {
                    PhongDTO phongDTO = new PhongDTO
                    {
                        MaPhong = Convert.ToInt32(txtMaPhong.Text),
                        Gia = Convert.ToInt32(txtGiaPhong.Text),
                        MaLoaiPhong = cboMaLoaiPhong.SelectedValue.ToString(),
                        TinhTrang = cboTinhTrang.SelectedItem.ToString()
                    };
                    int result = _phongBUS.XoaPhong(phongDTO);
                    if (result > 0)
                    {
                        MessageBox.Show("Xóa thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvPhong.DataSource = _phongBUS.LayDSPhong();
                        txtMaPhong.Enabled = true;
                        txtMaPhong.Text = string.Empty;
                        txtGiaPhong.Text = string.Empty;
                        cboMaLoaiPhong.SelectedIndex = 0;
                        cboTinhTrang.SelectedIndex = 0;
                    }
                    else
                    {
                        MessageBox.Show("Xóa thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
