﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
using DTO;
namespace Do_an_quan_ly_khach_san
{
    public partial class Ql_Nhan_vien : Form
    {
        private NhanVienDTO _nhanVienDTO = new NhanVienDTO();
        private NhanVienBUS _nhanVienBUS = new NhanVienBUS();
        private ChucVuBUS _chucVuBUS = new ChucVuBUS();
        
        public Ql_Nhan_vien()
        {
            InitializeComponent();
            dgvQLNhanVien.AutoGenerateColumns = false;
            cboChucVu.DataSource = _chucVuBUS.LayDSChucVu();
            cboChucVu.DisplayMember = "TenCV";
            cboChucVu.ValueMember = "MaCV";
        }

        private void btnQuayLai_Click(object sender, EventArgs e)
        {
            Trang_chu f = new Trang_chu(true);
            this.Hide();
            f.ShowDialog();
        }

        private void Ql_Nhan_vien_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void btnTao_Click(object sender, EventArgs e)
        {
            txtMaNV.Text = (_nhanVienBUS.MaxMaNV() + 1).ToString();
        }

        private void Ql_Nhan_vien_Load(object sender, EventArgs e)
        {

            radNam.Checked = true;
            txtMaNV.Enabled = false;
            colChucVu.DataSource = _chucVuBUS.LayDSChucVu();
            colChucVu.DisplayMember = "TenCV";
            colChucVu.ValueMember = "MaCV";
            dgvQLNhanVien.DataSource = _nhanVienBUS.LayDSNhanVien();
            btnCapNhat.Enabled = false;
            btnXoa.Enabled = false;
        }
        //public string Catkhoangtrang(string str1, string str2, char[] ch)
        //{
        //    int dodai = str1.Length;
        //    String str3= "";
        //    for (int i=0;i<dodai;i++) {
        //        if(string.Compare(ch[i].ToString()," ")==0)
        //        {
        //            str2 = str1.Substring(0,i);
        //            str3 = str1.Substring(i, str1.Length - i);
        //            str3 = str3.Trim();
        //            char[] ch1 = str3.ToCharArray();
        //            return str2 + " " + Catkhoangtrang(str3, str2, ch1);
        //        }    
        //    }

        //}

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaNV.Text) || string.IsNullOrEmpty(txtHoTenNV.Text) || string.IsNullOrEmpty(txtDiaChi.Text)
               || string.IsNullOrEmpty(txtSDT.Text) || string.IsNullOrEmpty(txtMatKhau.Text) || string.IsNullOrEmpty(txtTenTK.Text))
            {
                MessageBox.Show(Constants.ERR_REQUIRED, Constants.MESSAGE_TITLE, MessageBoxButtons.OK);
            }
            else if (string.IsNullOrWhiteSpace(txtSDT.Text)||string.IsNullOrWhiteSpace(txtHoTenNV.Text)||string.IsNullOrWhiteSpace(cboChucVu.SelectedValue.ToString()) || string.IsNullOrWhiteSpace(txtDiaChi.Text) || string.IsNullOrWhiteSpace(txtTenTK.Text) || string.IsNullOrWhiteSpace(txtMatKhau.Text))
            {
                MessageBox.Show(Constants.NO_SPACE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtHoTenNV.Text = string.Empty;
                txtDiaChi.Text = string.Empty;
                txtTenTK.Text = string.Empty;
                txtMatKhau.Text = string.Empty;
                txtSDT.Text = string.Empty;
            }
            else if (Convert.ToInt32(txtSDT.Text) <= Constants.SO_MIN)
            {
                MessageBox.Show(Constants.NUMBER, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSDT.Text = string.Empty;
                return;
            }
            else if (Convert.ToInt32(txtMatKhau.Text.Length) > Constants.KY_TU_MAX || Convert.ToInt32(txtSDT.Text.Length) < Constants.KY_TU_MIN)
            {
                MessageBox.Show(Constants.ERR_PASSWORD, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMatKhau.Text = string.Empty;
                return;
            }
            else
            {
               if (!_nhanVienBUS.KiemTraDinhDangEmail(txtTenTK.Text))
                {
                    MessageBox.Show(Constants.ERR_ACCOUNT_FORMAT, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTenTK.Text = string.Empty;
                    return;
                }
                else
                {
                    NhanVienDTO nhanVienDTO = new NhanVienDTO
                    {
                        MaNV = Convert.ToInt32(txtMaNV.Text),
                        HoTenNV = txtHoTenNV.Text,
                        DiaChi = txtDiaChi.Text,
                        GioiTinh = radNam.Checked ? Constants.BOY : Constants.GIRL,
                        SDT = Convert.ToInt32(txtSDT.Text),
                        MaCV = Convert.ToInt32(cboChucVu.SelectedValue.ToString()),
                        TenTK = txtTenTK.Text,
                        MatKhau = txtMatKhau.Text,
                    };
                    int result = _nhanVienBUS.ThemNhanVien(nhanVienDTO);
                    if (result > 0)
                    {
                        MessageBox.Show(Constants.ADD_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvQLNhanVien.DataSource = _nhanVienBUS.LayDSNhanVien();
                        txtMaNV.Text = string.Empty;
                        txtHoTenNV.Text = string.Empty;
                        txtDiaChi.Text = string.Empty;
                        radNam.Checked = true;
                        txtSDT.Text = string.Empty;
                        cboChucVu.SelectedIndex = 0;
                        txtTenTK.Text = string.Empty;
                        txtMatKhau.Text = string.Empty;
                    }
                    else
                    {
                        MessageBox.Show(Constants.ADD_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaNV.Text) || string.IsNullOrEmpty(txtHoTenNV.Text) || string.IsNullOrEmpty(txtDiaChi.Text)
                || string.IsNullOrEmpty(txtSDT.Text) || string.IsNullOrEmpty(txtMatKhau.Text))
            {
                MessageBox.Show(Constants.ERR_REQUIRED, Constants.MESSAGE_TITLE, MessageBoxButtons.OK);
            }
            else if (string.IsNullOrWhiteSpace(txtHoTenNV.Text) || string.IsNullOrWhiteSpace(txtSDT.Text) || string.IsNullOrWhiteSpace(cboChucVu.SelectedValue.ToString()) || string.IsNullOrWhiteSpace(txtDiaChi.Text) || string.IsNullOrWhiteSpace(txtTenTK.Text) || string.IsNullOrWhiteSpace(txtMatKhau.Text))
            {
                MessageBox.Show(Constants.NO_SPACE, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtHoTenNV.Text = string.Empty;
                txtSDT.Text = string.Empty;
                txtDiaChi.Text = string.Empty;
                txtTenTK.Text = string.Empty;
                txtMatKhau.Text = string.Empty;
            }
            else if (Convert.ToInt32(txtSDT.Text) <= Constants.SO_MIN)
            {
                MessageBox.Show(Constants.NUMBER, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSDT.Text = string.Empty;
                return;
            }
            else if (Convert.ToInt32(txtMatKhau.Text.Length) > Constants.KY_TU_MAX || Convert.ToInt32(txtSDT.Text.Length) < Constants.KY_TU_MIN)
            {
                MessageBox.Show(Constants.ERR_PASSWORD, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMatKhau.Text = string.Empty;
                return;
            }
            else
            {
                if (!_nhanVienBUS.KiemTraDinhDangEmail(txtTenTK.Text))
                {
                    MessageBox.Show(Constants.ERR_ACCOUNT_FORMAT, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTenTK.Text = string.Empty;
                    return;
                }
                else
                {
                    NhanVienDTO nhanVienDTO = new NhanVienDTO
                    {
                        MaNV = Convert.ToInt32(txtMaNV.Text),
                        HoTenNV = txtHoTenNV.Text,
                        DiaChi = txtDiaChi.Text,
                        GioiTinh = radNam.Checked ? Constants.BOY : Constants.GIRL,
                        SDT = Convert.ToInt32(txtSDT.Text),
                        MaCV = Convert.ToInt32(cboChucVu.SelectedValue.ToString()),
                        TenTK = txtTenTK.Text,
                        MatKhau = txtMatKhau.Text,
                    };
                    int result = _nhanVienBUS.CapNhatNhanVien(nhanVienDTO);
                    if (result > 0)
                    {
                        MessageBox.Show(Constants.UPADATE_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvQLNhanVien.DataSource = _nhanVienBUS.LayDSNhanVien();
                        txtMaNV.Text = string.Empty;
                        txtHoTenNV.Text = string.Empty;
                        txtDiaChi.Text = string.Empty;
                        radNam.Checked = true;
                        txtSDT.Text = string.Empty;
                        cboChucVu.SelectedIndex = 0;
                        txtTenTK.Text = string.Empty;
                        txtMatKhau.Text = string.Empty;
                    }
                    else
                    {
                        MessageBox.Show(Constants.UPADATE_FAIL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {

            DialogResult dlr = MessageBox.Show(Constants.SURE_DELETE_STAFF, Constants.ERR_REQUIRED, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlr == DialogResult.Yes)
            {
                NhanVienDTO nhanVienDTO = new NhanVienDTO
                {
                    MaNV = Convert.ToInt32(txtMaNV.Text),
                    HoTenNV = txtHoTenNV.Text,
                    DiaChi = txtDiaChi.Text,
                    GioiTinh = radNam.Checked ? Constants.BOY : Constants.GIRL,
                    SDT = Convert.ToInt32(txtSDT.Text),
                    MaCV = Convert.ToInt32(cboChucVu.SelectedValue.ToString()),
                    TenTK = txtTenTK.Text,
                    MatKhau = txtMatKhau.Text,
                };
                if (!_nhanVienBUS.KiemTraNhanVienTrongHoaDon(Convert.ToInt32(txtMaNV.Text)))
                {

                    int result = _nhanVienBUS.XoaNhanVien(nhanVienDTO);
                    if (result > 0)
                    {
                        MessageBox.Show(Constants.DELETE_SUCCESS, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgvQLNhanVien.DataSource = _nhanVienBUS.LayDSNhanVien();
                        txtMaNV.Text = string.Empty;
                        txtHoTenNV.Text = string.Empty;
                        txtDiaChi.Text = string.Empty;
                        radNam.Checked = true;
                        txtSDT.Text = string.Empty;
                        cboChucVu.SelectedIndex = 0;
                        txtTenTK.Text = string.Empty;
                        txtMatKhau.Text = string.Empty;
                    }
                }
                else
                {
                    MessageBox.Show(Constants.STAFF_EXIST_BILL, Constants.MESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            txtMaNV.Text = string.Empty;
            txtHoTenNV.Text = string.Empty;
            txtDiaChi.Text = string.Empty;
            radNam.Checked = true;
            txtSDT.Text = string.Empty;
            cboChucVu.SelectedIndex = 0;
            txtTenTK.Text = string.Empty;
            txtMatKhau.Text = string.Empty;
            btnTao.Enabled = true;
            btnThem.Enabled = true;
            btnCapNhat.Enabled = false;
            btnXoa.Enabled = false;
        }

        private void dgvQLNhanVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            btnTao.Enabled = false;
            btnThem.Enabled = false;
            txtMaNV.Enabled = false;
            if (e.RowIndex < 0) return;
            txtMaNV.Text = dgvQLNhanVien.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtHoTenNV.Text = dgvQLNhanVien.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtDiaChi.Text = dgvQLNhanVien.Rows[e.RowIndex].Cells[2].Value.ToString();
            string gioiTinh = "";
            if (dgvQLNhanVien.SelectedRows.Count > 0)
            {
                gioiTinh = dgvQLNhanVien.SelectedRows[0].Cells[3].Value.ToString();
                if (gioiTinh == Constants.BOY)
                {
                    radNam.Checked = true;
                }
                else
                {
                    radNu.Checked = true;
                }
            }
            txtSDT.Text = dgvQLNhanVien.Rows[e.RowIndex].Cells[4].Value.ToString();
            cboChucVu.SelectedValue = dgvQLNhanVien.Rows[e.RowIndex].Cells[5].Value;
            txtTenTK.Text = dgvQLNhanVien.Rows[e.RowIndex].Cells[6].Value.ToString();
            txtMatKhau.Text = dgvQLNhanVien.Rows[e.RowIndex].Cells[7].Value.ToString();
            btnCapNhat.Enabled = true;
            btnXoa.Enabled = true;
        }

        private void txtHoTenNV_TextChanged(object sender, EventArgs e)
        {
        }

        //private void txtHoTenNV_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    e.Handled = !((e.KeyChar >= 65 && e.KeyChar <= 122) || (e.KeyChar == 8));
               
        //}

        private void txtSDT_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSDT_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtTenTK_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Bao_Cao bao_cao = new Bao_Cao();
            bao_cao.TatCaNhanVien();
            bao_cao.ShowDialog();
        }
    } 
}
